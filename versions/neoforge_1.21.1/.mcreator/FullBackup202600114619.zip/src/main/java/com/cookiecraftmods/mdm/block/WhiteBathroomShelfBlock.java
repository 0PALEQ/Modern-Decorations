package com.cookiecraftmods.mdm.block;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.IBlockReader;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Rotation;
import net.minecraft.util.Mirror;
import net.minecraft.util.Direction;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.state.StateContainer;
import net.minecraft.state.DirectionProperty;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.block.material.Material;
import net.minecraft.block.SoundType;
import net.minecraft.block.HorizontalBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Block;

import com.google.common.collect.ImmutableMap;

public class WhiteBathroomShelfBlock extends Block {
	public static final DirectionProperty FACING = HorizontalBlock.HORIZONTAL_FACING;
	private final ImmutableMap<BlockState, VoxelShape> shapes = this.makeShapes();

	public WhiteBathroomShelfBlock() {
		super(Block.Properties.create(Material.REDSTONE_LIGHT).sound(SoundType.WOOD).hardnessAndResistance(1f, 10f));
		this.setDefaultState(this.stateContainer.getBaseState().with(FACING, Direction.NORTH));
	}

	@Override
	public boolean isSolid(BlockState state) {
		return false;
	}

	private ImmutableMap<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			switch (state.get(FACING)) {
				case NORTH :
					return VoxelShapes.or(makeCuboidShape(0, 0, 9, 16, 16, 16), makeCuboidShape(1, 1, 8.5, 7, 15, 9), makeCuboidShape(9, 1, 8.5, 15, 15, 9), makeCuboidShape(6, 6, 8.25, 6.5, 13, 8.5), makeCuboidShape(9.5, 6, 8.25, 10, 13, 8.5));
				case EAST :
					return VoxelShapes.or(makeCuboidShape(0, 0, 0, 7, 16, 16), makeCuboidShape(7, 1, 1, 7.5, 15, 7), makeCuboidShape(7, 1, 9, 7.5, 15, 15), makeCuboidShape(7.5, 6, 6, 7.75, 13, 6.5), makeCuboidShape(7.5, 6, 9.5, 7.75, 13, 10));
				case WEST :
					return VoxelShapes.or(makeCuboidShape(9, 0, 0, 16, 16, 16), makeCuboidShape(8.5, 1, 9, 9, 15, 15), makeCuboidShape(8.5, 1, 1, 9, 15, 7), makeCuboidShape(8.25, 6, 9.5, 8.5, 13, 10), makeCuboidShape(8.25, 6, 6, 8.5, 13, 6.5));
				default :
					return VoxelShapes.or(makeCuboidShape(0, 0, 0, 16, 16, 7), makeCuboidShape(9, 1, 7, 15, 15, 7.5), makeCuboidShape(1, 1, 7, 7, 15, 7.5), makeCuboidShape(9.5, 6, 7.5, 10, 13, 7.75), makeCuboidShape(6, 6, 7.5, 6.5, 13, 7.75));
			}
		});
	}

	private ImmutableMap<BlockState, VoxelShape> getShapeForEachState(Function<BlockState, VoxelShape> func) {
		return stateContainer.getValidStates().stream().collect(ImmutableMap.toImmutableMap(Function.identity(), func));
	}

	@Override
	public VoxelShape getShape(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext context) {
		return shapes.get(state);
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public BlockRenderLayer getRenderLayer() {
		return BlockRenderLayer.CUTOUT;
	}

	@Override
	public boolean isNormalCube(BlockState state, IBlockReader worldIn, BlockPos pos) {
		return false;
	}

	@Override
	public VoxelShape getRaytraceShape(BlockState state, IBlockReader world, BlockPos pos) {
		return VoxelShapes.empty();
	}

	@Override
	protected void fillStateContainer(StateContainer.Builder<Block, BlockState> builder) {
		super.fillStateContainer(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockItemUseContext context) {
		return super.getStateForPlacement(context).with(FACING, context.getPlacementHorizontalFacing().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.with(FACING, rot.rotate(state.get(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.toRotation(state.get(FACING)));
	}
}