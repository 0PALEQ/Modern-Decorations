package com.cookiecraftmods.mdm.block;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.IEnviromentBlockReader;
import net.minecraft.world.IBlockReader;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Rotation;
import net.minecraft.util.Mirror;
import net.minecraft.util.Direction;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.state.StateContainer;
import net.minecraft.state.DirectionProperty;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.block.material.Material;
import net.minecraft.block.SoundType;
import net.minecraft.block.HorizontalBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Block;

import com.google.common.collect.ImmutableMap;

public class BathroomMirrorBlock extends Block {
	public static final DirectionProperty FACING = HorizontalBlock.HORIZONTAL_FACING;
	private final ImmutableMap<BlockState, VoxelShape> shapes = this.makeShapes();

	public BathroomMirrorBlock() {
		super(Block.Properties.create(Material.REDSTONE_LIGHT).sound(SoundType.GLASS).hardnessAndResistance(1f, 10f));
		this.setDefaultState(this.stateContainer.getBaseState().with(FACING, Direction.NORTH));
	}

	@Override
	public boolean isSolid(BlockState state) {
		return false;
	}

	private ImmutableMap<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			switch (state.get(FACING)) {
				case NORTH :
					return VoxelShapes.or(makeCuboidShape(1, 1, 14, 15, 3, 16), makeCuboidShape(1, 1.5, 13, 2, 2.5, 15), makeCuboidShape(14, 1.5, 12, 15, 2.5, 14), makeCuboidShape(0.5, 0.7, 12.3, 2.5, 2.7, 13.3),
							makeCuboidShape(13.5, 0.7, 12.3, 15.5, 2.7, 13.3), makeCuboidShape(3, -12, 15.5, 13, -1, 15.75), makeCuboidShape(4, -11, 15.75, 12, -2, 16), makeCuboidShape(3, -12, 13, 13, -11.75, 15.5));
				case EAST :
					return VoxelShapes.or(makeCuboidShape(0, 1, 1, 2, 3, 15), makeCuboidShape(1, 1.5, 1, 3, 2.5, 2), makeCuboidShape(2, 1.5, 14, 4, 2.5, 15), makeCuboidShape(2.7, 0.7, 0.5, 3.7, 2.7, 2.5),
							makeCuboidShape(2.7, 0.7, 13.5, 3.7, 2.7, 15.5), makeCuboidShape(0.25, -12, 3, 0.5, -1, 13), makeCuboidShape(0, -11, 4, 0.25, -2, 12), makeCuboidShape(0.5, -12, 3, 3, -11.75, 13));
				case WEST :
					return VoxelShapes.or(makeCuboidShape(14, 1, 1, 16, 3, 15), makeCuboidShape(13, 1.5, 14, 15, 2.5, 15), makeCuboidShape(12, 1.5, 1, 14, 2.5, 2), makeCuboidShape(12.3, 0.7, 13.5, 13.3, 2.7, 15.5),
							makeCuboidShape(12.3, 0.7, 0.5, 13.3, 2.7, 2.5), makeCuboidShape(15.5, -12, 3, 15.75, -1, 13), makeCuboidShape(15.75, -11, 4, 16, -2, 12), makeCuboidShape(13, -12, 3, 15.5, -11.75, 13));
				default :
					return VoxelShapes.or(makeCuboidShape(1, 1, 0, 15, 3, 2), makeCuboidShape(14, 1.5, 1, 15, 2.5, 3), makeCuboidShape(1, 1.5, 2, 2, 2.5, 4), makeCuboidShape(13.5, 0.7, 2.7, 15.5, 2.7, 3.7),
							makeCuboidShape(0.5, 0.7, 2.7, 2.5, 2.7, 3.7), makeCuboidShape(3, -12, 0.25, 13, -1, 0.5), makeCuboidShape(4, -11, 0, 12, -2, 0.25), makeCuboidShape(3, -12, 0.5, 13, -11.75, 3));
			}
		});
	}

	private ImmutableMap<BlockState, VoxelShape> getShapeForEachState(Function<BlockState, VoxelShape> func) {
		return stateContainer.getValidStates().stream().collect(ImmutableMap.toImmutableMap(Function.identity(), func));
	}

	@Override
	public VoxelShape getShape(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext context) {
		return shapes.get(state);
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public BlockRenderLayer getRenderLayer() {
		return BlockRenderLayer.CUTOUT;
	}

	@Override
	public boolean isNormalCube(BlockState state, IBlockReader worldIn, BlockPos pos) {
		return false;
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public int getPackedLightmapCoords(BlockState state, IEnviromentBlockReader worldIn, BlockPos pos) {
		return 15728880;
	}

	@Override
	public boolean needsPostProcessing(BlockState state, IBlockReader worldIn, BlockPos pos) {
		return true;
	}

	@Override
	public VoxelShape getRaytraceShape(BlockState state, IBlockReader world, BlockPos pos) {
		return VoxelShapes.empty();
	}

	@Override
	protected void fillStateContainer(StateContainer.Builder<Block, BlockState> builder) {
		super.fillStateContainer(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockItemUseContext context) {
		return super.getStateForPlacement(context).with(FACING, context.getPlacementHorizontalFacing().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.with(FACING, rot.rotate(state.get(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.toRotation(state.get(FACING)));
	}
}