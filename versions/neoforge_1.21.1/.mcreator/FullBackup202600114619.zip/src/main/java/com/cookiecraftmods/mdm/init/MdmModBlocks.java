/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.cookiecraftmods.mdm.init;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.world.NoteBlockEvent;

import net.minecraft.state.properties.NoteBlockInstrument;
import net.minecraft.block.Block;

import com.cookiecraftmods.mdm.block.*;
import com.cookiecraftmods.mdm.MdmMod;

public class MdmModBlocks {
	public static final DeferredRegister<Block> REGISTRY = new DeferredRegister<>(ForgeRegistries.BLOCKS, MdmMod.MODID);
	public static final RegistryObject<Block> BLACK_MODERN_FRIDGE_1;
	public static final RegistryObject<Block> LEAFLESS_BAMBOO_DECORATION_1;
	public static final RegistryObject<Block> LEAFLESS_BAMBOO_DECORATION_2;
	public static final RegistryObject<Block> LEAFLESS_BAMBOO_DECORATION_3;
	public static final RegistryObject<Block> BLACK_MODER_STAIRS;
	public static final RegistryObject<Block> WHITE_MODERN_STAIRS;
	public static final RegistryObject<Block> RED_MODERN_STAIRS;
	public static final RegistryObject<Block> BLUE_MODERN_STAIRS;
	public static final RegistryObject<Block> GREEN_MODERN_STAIRS;
	public static final RegistryObject<Block> STEEL_SHELF;
	public static final RegistryObject<Block> BLACK_LAMP;
	public static final RegistryObject<Block> COUCHLEFT;
	public static final RegistryObject<Block> COUCHMIDDLE;
	public static final RegistryObject<Block> COUCH_RIGHT;
	public static final RegistryObject<Block> COUCH_CORNER;
	public static final RegistryObject<Block> SOFA;
	public static final RegistryObject<Block> HAND_SOAP_AND_CREAM_SET;
	public static final RegistryObject<Block> TOILET_PAPER_ROLL;
	public static final RegistryObject<Block> SOAP_BAR;
	public static final RegistryObject<Block> TOILET;
	public static final RegistryObject<Block> BATHROOM_SINK;
	public static final RegistryObject<Block> BATHROOM_SINK_WITH_SHELF;
	public static final RegistryObject<Block> BLACK_WASHBASIN_TAP;
	public static final RegistryObject<Block> WHITE_BATHROOM_SHELF;
	public static final RegistryObject<Block> RING_LAMP;
	public static final RegistryObject<Block> WHITE_BATHTUB;
	public static final RegistryObject<Block> TOWEL_SET_1;
	public static final RegistryObject<Block> TOOTHBRUSHES;
	public static final RegistryObject<Block> CHLOTHESBIN;
	public static final RegistryObject<Block> BATHROOM_STAND;
	public static final RegistryObject<Block> PILE_OF_TOWELS;
	public static final RegistryObject<Block> WALKIN_SHOWER;
	public static final RegistryObject<Block> RAIN_SHOWER;
	public static final RegistryObject<Block> BLACK_OFFICE_DESK;
	public static final RegistryObject<Block> BLACK_DESK_EXTENSION_1;
	public static final RegistryObject<Block> BLACK_DESK_EXTENSION_2;
	public static final RegistryObject<Block> BLACK_DESK_EXTENSION_3;
	public static final RegistryObject<Block> OFFICE_CABINET_1;
	public static final RegistryObject<Block> OFFICE_CABINET_2;
	public static final RegistryObject<Block> OFFICE_CABINET_3;
	public static final RegistryObject<Block> OFFICE_SHELF;
	public static final RegistryObject<Block> BATHROOM_MIRROR;
	public static final RegistryObject<Block> MODERN_DESK_1;
	public static final RegistryObject<Block> MODERN_DESK_2;
	public static final RegistryObject<Block> SHELF;
	public static final RegistryObject<Block> HANGING_SHELF;
	public static final RegistryObject<Block> CARPET_1;
	public static final RegistryObject<Block> BLACK_DESK_LAMP;
	public static final RegistryObject<Block> MODERN_LAMP_1;
	public static final RegistryObject<Block> MODERN_DESK_LAMP_1;
	public static final RegistryObject<Block> MODERN_CHANDELIER_1;
	public static final RegistryObject<Block> SET_1_CABINET;
	public static final RegistryObject<Block> SET_1_CABINET_WITH_DRAWERS;
	public static final RegistryObject<Block> SET_1_CORNER_CABINET_1;
	public static final RegistryObject<Block> SET_1_CORNER_CABINET_2;
	public static final RegistryObject<Block> SET_1_ISLAND_1;
	public static final RegistryObject<Block> SET_1_ISLAND_2;
	public static final RegistryObject<Block> SET_1_OVEN_MICROWAVE;
	public static final RegistryObject<Block> SET_1_FRIDGE;
	public static final RegistryObject<Block> SET_1_CABINET_2;
	public static final RegistryObject<Block> SET_1_HANGING_CABINET;
	public static final RegistryObject<Block> SET_1_CORNER_HANGING_CABINET;
	public static final RegistryObject<Block> DOCUMENT_FOLDERS;
	public static final RegistryObject<Block> SET_2_CABINET_1;
	public static final RegistryObject<Block> SET_2_CABINET_2;
	public static final RegistryObject<Block> SET_2_CABINET_3;
	public static final RegistryObject<Block> SET_2_CABINET_WITH_DRAWERS;
	public static final RegistryObject<Block> SET_2_HANGING_SHELF;
	public static final RegistryObject<Block> SET_2_CORNER_COUNTER;
	public static final RegistryObject<Block> BASKETS;
	public static final RegistryObject<Block> OVEN;
	public static final RegistryObject<Block> INDUCTION_COOKER;
	public static final RegistryObject<Block> TV_STAND_MID;
	public static final RegistryObject<Block> TV_STAND_LEFT;
	public static final RegistryObject<Block> TV_STAND_RIGHT;
	public static final RegistryObject<Block> TV_STAND_MID_DECORATED;
	public static final RegistryObject<Block> POOL_TABLE;
	public static final RegistryObject<Block> POTTED_TREE;
	public static final RegistryObject<Block> OUTDOOR_COUCH;
	public static final RegistryObject<Block> OUTDOOR_TABLE;
	public static final RegistryObject<Block> LANTERN;
	public static final RegistryObject<Block> STREET_LANTERN_BOTTOM;
	public static final RegistryObject<Block> STREET_LANTERN_MID;
	public static final RegistryObject<Block> STREET_LATERN_TOP;
	public static final RegistryObject<Block> CEILLING_FAN;
	public static final RegistryObject<Block> SET_1_NIGHT_TABLE;
	public static final RegistryObject<Block> SET_1_BED;
	public static final RegistryObject<Block> SET_1_FOOTREST;
	public static final RegistryObject<Block> LIGHT_GREY_COUCH_MIDDLE;
	public static final RegistryObject<Block> LIGHT_GRAY_COUCH_LEFT;
	public static final RegistryObject<Block> LIGHT_GREY_COUCH_RIGHT;
	public static final RegistryObject<Block> GREY_COUCH_MIDDLE;
	public static final RegistryObject<Block> GREY_COUCH_LEFT;
	public static final RegistryObject<Block> GREY_COUCH_RIGHT;
	public static final RegistryObject<Block> GREY_COUCH_CORNER;
	public static final RegistryObject<Block> GREY_SOFA;
	public static final RegistryObject<Block> SET_1_COFFE_TABLE_1_SHORT;
	public static final RegistryObject<Block> SET_1_COFFE_TABLE_1_TALL;
	public static final RegistryObject<Block> SET_1_COFFE_TABLE_2;
	public static final RegistryObject<Block> SET_3_COFFE_TABLE;
	public static final RegistryObject<Block> SET_3_COFFE_TABLE_DECORATED;
	public static final RegistryObject<Block> SET_3TV_STAND;
	public static final RegistryObject<Block> SET_1_TV_STAND;
	public static final RegistryObject<Block> SET_1_TV_STAND_MIDDLE;
	public static final RegistryObject<Block> BLACK_WALL_CLOCK;
	public static final RegistryObject<Block> WOODEN_WALL_CLOCK;
	public static final RegistryObject<Block> SET_1_CHAIR;
	public static final RegistryObject<Block> SET_1_LIVINGROOM_CABINET;
	public static final RegistryObject<Block> SET_1_LIVINGROOM_CABINET_2;
	public static final RegistryObject<Block> SET_1_COFFEE_TABLE_2_MIDDLE;
	public static final RegistryObject<Block> SET_1_LIVINGROOM_HANGING_CABINET;
	public static final RegistryObject<Block> KITCHEN_SET_3_CORNER_COUNTER;
	public static final RegistryObject<Block> KITCHEN_SET_3_CORNER_COUNTER_WITH_SINK;
	public static final RegistryObject<Block> KITCHEN_SET_3_COUNTER;
	public static final RegistryObject<Block> KITCHEN_SET_3_COUNTER_2;
	public static final RegistryObject<Block> KITCHEN_SET_3_COUNTER_3;
	public static final RegistryObject<Block> KITCHEN_SET_3_DISHWASHER;
	public static final RegistryObject<Block> KITCHEN_SET_3_FRIDGE_BOTTOM;
	public static final RegistryObject<Block> KITCHEN_SET_3_FRIDGE_TOP;
	public static final RegistryObject<Block> KITCHEN_SET_3_HANGING_CABINET;
	public static final RegistryObject<Block> KITCHEN_SET_3_OVEN_BOTTOM;
	public static final RegistryObject<Block> KITCHEN_SET_3_OVEN_TOP;
	public static final RegistryObject<Block> KITCHEN_SET_3_SMALL_CORNER_HANGING_CABINET;
	public static final RegistryObject<Block> KITCHEN_SET_3_SMALL_HANGING_CABINET;
	public static final RegistryObject<Block> KITCHEN_SET_3_HANGING_CORNER_CABINET;
	public static final RegistryObject<Block> GAS_STOVE;
	public static final RegistryObject<Block> KITCHEN_SET_3_BAR_CHAIR;
	public static final RegistryObject<Block> BEDROOMSET_1_BLACK_LOVESEAT;
	public static final RegistryObject<Block> BEDROOM_SET_1GREYDRESSERLEFT;
	public static final RegistryObject<Block> BEDROOM_SET_1GREYDRESSERMID;
	public static final RegistryObject<Block> BEDROOM_SET_1GREYDRESSERRIGHT;
	public static final RegistryObject<Block> BEDROOM_SET_1GREY_SINGLE_BED;
	public static final RegistryObject<Block> BEDROOM_SET_1GREY_DOUBLE_BED;
	public static final RegistryObject<Block> BEDROOM_SET_1GREY_BUNK_BED;
	public static final RegistryObject<Block> BEDROOM_SET_1GREYWARDROBE;
	public static final RegistryObject<Block> BEDROOM_SET_1GREYLOVESEAT;
	public static final RegistryObject<Block> BEDROOM_SET_1GREY_NIGHTSTAND_1;
	public static final RegistryObject<Block> BEDROOM_SET_1GREY_NIGHTSTAND_2;
	public static final RegistryObject<Block> BEDROOM_SET_1WENGEBUNKBED;
	public static final RegistryObject<Block> BEDROOM_SET_1WENGE_DOUBLE_BED;
	public static final RegistryObject<Block> BEDROOM_SET_1WENGE_SINGLE_BED;
	public static final RegistryObject<Block> BEDROOM_SET_1WENGEDRESSERMID;
	public static final RegistryObject<Block> BEDROOM_SET_1WENGEDRESSERLEFT;
	public static final RegistryObject<Block> BEDROOM_SET_1WENGEDRESSERRIGHT;
	public static final RegistryObject<Block> BEDROOM_SET_1WENGEWARDROBE;
	public static final RegistryObject<Block> BEDROOM_SET_1WENGENIGHTSTAND_1;
	public static final RegistryObject<Block> BEDROOM_SET_1WENGENIGHSTAND_2;
	public static final RegistryObject<Block> BEDROOM_SET_1WHITEBUNKBED;
	public static final RegistryObject<Block> BEDROOM_SET_1WHITE_DOUBLEBED;
	public static final RegistryObject<Block> BEDROOM_SET_1WHITE_SINGLEBED;
	public static final RegistryObject<Block> BEDROOM_SET_1WHITEDRESSERLEFT;
	public static final RegistryObject<Block> BEDROOM_SET_1WHITEDRESSERMID;
	public static final RegistryObject<Block> BEDROOM_SET_1WHITEDRESSERRIGHT;
	public static final RegistryObject<Block> BEDROOM_SET_1WHITEWARDROBE;
	public static final RegistryObject<Block> BEDROOM_SET_1WHITELOVESEAT;
	public static final RegistryObject<Block> BEDROOM_SET_1WHITENIGHTSTAND_1;
	public static final RegistryObject<Block> BEDROOM_SET_1WHITENIGHSTAND_2;
	public static final RegistryObject<Block> OFFICE_SET_1_DESK_2_MID;
	public static final RegistryObject<Block> OFFICE_SET_1_DESK_2_SIDE;
	public static final RegistryObject<Block> OFFICE_SET_1_DESK_2_SIDE_VAR_2;
	public static final RegistryObject<Block> OFFICE_SET_1_BOOKSHELF_VAR_1_BOTTOM;
	public static final RegistryObject<Block> OFFICE_SET_1_BOOKSHELF_VAR_1_TOP;
	public static final RegistryObject<Block> OFFICE_SET_1_SHELF_VAR_1_BOTTOM;
	public static final RegistryObject<Block> OFFICE_SET_1_SHELF_VAR_1_TOP;
	public static final RegistryObject<Block> OFFICE_SET_1_SHELF_VAR_2_BOTTOM;
	public static final RegistryObject<Block> OFFICE_SET_1_SHELF_VAR_2_TOP;
	public static final RegistryObject<Block> OFFICE_SET_1_DESK_1_CABINET;
	public static final RegistryObject<Block> OFFICE_SET_1_DESK_1_CABINET_VAR_2;
	public static final RegistryObject<Block> OFFICE_SET_1_DESK_1_CABINET_VAR_3;
	public static final RegistryObject<Block> OFFICE_SET_1_DESK_1_CABINET_VAR_4;
	public static final RegistryObject<Block> OFFICE_SET_1_DESK_1_LEFT;
	public static final RegistryObject<Block> OFFICE_SET_1_DESK_1_LEFT_VAR_2;
	public static final RegistryObject<Block> OFFICE_SET_1_DESK_1_LEFT_VAR_3;
	public static final RegistryObject<Block> OFFICE_SET_1_DESK_1_MIDDLE;
	public static final RegistryObject<Block> OFFICE_SET_1_DESK_1_RIGHT;
	public static final RegistryObject<Block> OFFICE_SET_1_DESK_1_RIGHT_VAR_2;
	public static final RegistryObject<Block> OFFICE_SET_1_DESK_1_RIGHT_VAR_3;
	public static final RegistryObject<Block> OFFICE_SET_1_CHAIR;
	public static final RegistryObject<Block> OFFICE_SET_1_DESK_LAMP;
	public static final RegistryObject<Block> BLACK_BENCH;
	public static final RegistryObject<Block> WHITE_BENCH;
	public static final RegistryObject<Block> CARPET_2;
	public static final RegistryObject<Block> CARPET_3;
	public static final RegistryObject<Block> CARPET_4;
	public static final RegistryObject<Block> WHITE_BOARD;
	public static final RegistryObject<Block> STANDING_WHITE_BOARD;
	public static final RegistryObject<Block> CORK_BOARD;
	public static final RegistryObject<Block> MODERN_PAINTING;
	public static final RegistryObject<Block> MODERN_PAINTING_2;
	public static final RegistryObject<Block> WHITE_CURTAIN;
	public static final RegistryObject<Block> WHITE_CURTAIN_LEFT;
	public static final RegistryObject<Block> WHITE_CURTAIN_RIGHT;
	public static final RegistryObject<Block> RED_CURTAIN;
	public static final RegistryObject<Block> RED_CURTAIN_LEFT;
	public static final RegistryObject<Block> RED_CURTAIN_RIGHT;
	public static final RegistryObject<Block> CURTAIN_RACK;
	public static final RegistryObject<Block> BLACK_CURTAIN;
	public static final RegistryObject<Block> BLACK_CURTAIN_LEFT;
	public static final RegistryObject<Block> BLACK_CURTAIN_RIGHT;
	public static final RegistryObject<Block> GREY_CURTAIN;
	public static final RegistryObject<Block> GREY_CURTAIN_LEFT;
	public static final RegistryObject<Block> GREY_CURTAIN_RIGHT;
	public static final RegistryObject<Block> BLUE_CURTAIN;
	public static final RegistryObject<Block> BLUE_CURTAIN_LEFT;
	public static final RegistryObject<Block> BLUE_CURTAIN_RIGHT;
	public static final RegistryObject<Block> GREEN_CURTAIN;
	public static final RegistryObject<Block> GREEN_CURTAIN_LEFT;
	public static final RegistryObject<Block> GREEN_CURTAIN_RIGHT;
	public static final RegistryObject<Block> FOYER_WALL_UNIT_BOTTOM;
	public static final RegistryObject<Block> FOYER_WALL_UNIT_TOP;
	public static final RegistryObject<Block> WHITE_WOOD_FOYER_WALL_UNIT;
	public static final RegistryObject<Block> WHITE_WOOD_FOYER_WALL_UNIT_TOP;
	public static final RegistryObject<Block> BLACK_FOYER_WALL_UNIT;
	public static final RegistryObject<Block> BLACK_FOYER_WALL_UNIT_TOP;
	public static final RegistryObject<Block> WHITE_ARMCHAIR;
	public static final RegistryObject<Block> BLACK_ARMCHAIR;
	public static final RegistryObject<Block> SMALL_TABLE;
	public static final RegistryObject<Block> SMALL_CHANDELIER;
	public static final RegistryObject<Block> SMALL_CEILING_LAMP;
	public static final RegistryObject<Block> BIG_CEILING_LIGHT;
	public static final RegistryObject<Block> BIG_CEILING_LAMP;
	public static final RegistryObject<Block> BATHROOM_RADIATOR;
	public static final RegistryObject<Block> BATHROOM_SHELF_02;
	public static final RegistryObject<Block> BOWL;
	public static final RegistryObject<Block> CHOPPING_BOARD;
	public static final RegistryObject<Block> COFFEE_TABLE_04;
	public static final RegistryObject<Block> CRIB;
	public static final RegistryObject<Block> FORK;
	public static final RegistryObject<Block> KNIFE;
	public static final RegistryObject<Block> KNIFE_STAND;
	public static final RegistryObject<Block> LAMP_03;
	public static final RegistryObject<Block> MUG;
	public static final RegistryObject<Block> PAINTING_05;
	public static final RegistryObject<Block> PLATE;
	public static final RegistryObject<Block> POTTED_CACTUS;
	public static final RegistryObject<Block> POUF;
	public static final RegistryObject<Block> SEASONING_RACK;
	public static final RegistryObject<Block> SPOON;
	public static final RegistryObject<Block> WALL_LAMP;
	public static final RegistryObject<Block> WALL_LAMP_2;
	public static final RegistryObject<Block> WINDOW_BLINDS;
	public static final RegistryObject<Block> PAINTING_03;
	public static final RegistryObject<Block> PAINTING_04;
	public static final RegistryObject<Block> BOXES;
	public static final RegistryObject<Block> COAT_HANGER;
	public static final RegistryObject<Block> DOOR_MAT;
	public static final RegistryObject<Block> ELECTRIC_GUITAR_BLACK;
	public static final RegistryObject<Block> ELECTRIC_GUITAR_WITH_STAND;
	public static final RegistryObject<Block> ENTRYWAY_CARPET;
	public static final RegistryObject<Block> FOYER_BENCH;
	public static final RegistryObject<Block> FOYER_BENCH_DARK;
	public static final RegistryObject<Block> FOYER_BENCH_WHITE;
	public static final RegistryObject<Block> FOYER_BENCH_WENGE;
	public static final RegistryObject<Block> PAIR_OF_BOOTS;
	public static final RegistryObject<Block> PAIR_OF_BOOTS_2;
	public static final RegistryObject<Block> PAIR_OF_BOOTS_3;
	public static final RegistryObject<Block> PAIR_OF_BOOTS_4;
	public static final RegistryObject<Block> PAIR_OF_BOOTS_5;
	public static final RegistryObject<Block> PAIR_OF_BOOTS_6;
	public static final RegistryObject<Block> SHOE_RACK;
	public static final RegistryObject<Block> SHOE_RACK_2;
	public static final RegistryObject<Block> SHOE_RACK_3;
	public static final RegistryObject<Block> TALL_MIRROR;
	static {
		BLACK_MODERN_FRIDGE_1 = REGISTRY.register("black_modern_fridge_1", BlackModernFridge1Block::new);
		LEAFLESS_BAMBOO_DECORATION_1 = REGISTRY.register("leafless_bamboo_decoration_1", LeaflessBambooDecoration1Block::new);
		LEAFLESS_BAMBOO_DECORATION_2 = REGISTRY.register("leafless_bamboo_decoration_2", LeaflessBambooDecoration2Block::new);
		LEAFLESS_BAMBOO_DECORATION_3 = REGISTRY.register("leafless_bamboo_decoration_3", LeaflessBambooDecoration3Block::new);
		BLACK_MODER_STAIRS = REGISTRY.register("black_moder_stairs", BlackModerStairsBlock::new);
		WHITE_MODERN_STAIRS = REGISTRY.register("white_modern_stairs", WhiteModernStairsBlock::new);
		RED_MODERN_STAIRS = REGISTRY.register("red_modern_stairs", RedModernStairsBlock::new);
		BLUE_MODERN_STAIRS = REGISTRY.register("blue_modern_stairs", BlueModernStairsBlock::new);
		GREEN_MODERN_STAIRS = REGISTRY.register("green_modern_stairs", GreenModernStairsBlock::new);
		STEEL_SHELF = REGISTRY.register("steel_shelf", SteelShelfBlock::new);
		BLACK_LAMP = REGISTRY.register("black_lamp", BlackLampBlock::new);
		COUCHLEFT = REGISTRY.register("couchleft", CouchleftBlock::new);
		COUCHMIDDLE = REGISTRY.register("couchmiddle", CouchmiddleBlock::new);
		COUCH_RIGHT = REGISTRY.register("couch_right", CouchRightBlock::new);
		COUCH_CORNER = REGISTRY.register("couch_corner", CouchCornerBlock::new);
		SOFA = REGISTRY.register("sofa", SofaBlock::new);
		HAND_SOAP_AND_CREAM_SET = REGISTRY.register("hand_soap_and_cream_set", HandSoapAndCreamSetBlock::new);
		TOILET_PAPER_ROLL = REGISTRY.register("toilet_paper_roll", ToiletPaperRollBlock::new);
		SOAP_BAR = REGISTRY.register("soap_bar", SoapBarBlock::new);
		TOILET = REGISTRY.register("toilet", ToiletBlock::new);
		BATHROOM_SINK = REGISTRY.register("bathroom_sink", BathroomSinkBlock::new);
		BATHROOM_SINK_WITH_SHELF = REGISTRY.register("bathroom_sink_with_shelf", BathroomSinkWithShelfBlock::new);
		BLACK_WASHBASIN_TAP = REGISTRY.register("black_washbasin_tap", BlackWashbasinTapBlock::new);
		WHITE_BATHROOM_SHELF = REGISTRY.register("white_bathroom_shelf", WhiteBathroomShelfBlock::new);
		RING_LAMP = REGISTRY.register("ring_lamp", RingLampBlock::new);
		WHITE_BATHTUB = REGISTRY.register("white_bathtub", WhiteBathtubBlock::new);
		TOWEL_SET_1 = REGISTRY.register("towel_set_1", TowelSet1Block::new);
		TOOTHBRUSHES = REGISTRY.register("toothbrushes", ToothbrushesBlock::new);
		CHLOTHESBIN = REGISTRY.register("chlothesbin", ChlothesbinBlock::new);
		BATHROOM_STAND = REGISTRY.register("bathroom_stand", BathroomStandBlock::new);
		PILE_OF_TOWELS = REGISTRY.register("pile_of_towels", PileOfTowelsBlock::new);
		WALKIN_SHOWER = REGISTRY.register("walkin_shower", WalkinShowerBlock::new);
		RAIN_SHOWER = REGISTRY.register("rain_shower", RainShowerBlock::new);
		BLACK_OFFICE_DESK = REGISTRY.register("black_office_desk", BlackOfficeDeskBlock::new);
		BLACK_DESK_EXTENSION_1 = REGISTRY.register("black_desk_extension_1", BlackDeskExtension1Block::new);
		BLACK_DESK_EXTENSION_2 = REGISTRY.register("black_desk_extension_2", BlackDeskExtension2Block::new);
		BLACK_DESK_EXTENSION_3 = REGISTRY.register("black_desk_extension_3", BlackDeskExtension3Block::new);
		OFFICE_CABINET_1 = REGISTRY.register("office_cabinet_1", OfficeCabinet1Block::new);
		OFFICE_CABINET_2 = REGISTRY.register("office_cabinet_2", OfficeCabinet2Block::new);
		OFFICE_CABINET_3 = REGISTRY.register("office_cabinet_3", OfficeCabinet3Block::new);
		OFFICE_SHELF = REGISTRY.register("office_shelf", OfficeShelfBlock::new);
		BATHROOM_MIRROR = REGISTRY.register("bathroom_mirror", BathroomMirrorBlock::new);
		MODERN_DESK_1 = REGISTRY.register("modern_desk_1", ModernDesk1Block::new);
		MODERN_DESK_2 = REGISTRY.register("modern_desk_2", ModernDesk2Block::new);
		SHELF = REGISTRY.register("shelf", ShelfBlock::new);
		HANGING_SHELF = REGISTRY.register("hanging_shelf", HangingShelfBlock::new);
		CARPET_1 = REGISTRY.register("carpet_1", Carpet1Block::new);
		BLACK_DESK_LAMP = REGISTRY.register("black_desk_lamp", BlackDeskLampBlock::new);
		MODERN_LAMP_1 = REGISTRY.register("modern_lamp_1", ModernLamp1Block::new);
		MODERN_DESK_LAMP_1 = REGISTRY.register("modern_desk_lamp_1", ModernDeskLamp1Block::new);
		MODERN_CHANDELIER_1 = REGISTRY.register("modern_chandelier_1", ModernChandelier1Block::new);
		SET_1_CABINET = REGISTRY.register("set_1_cabinet", Set1CabinetBlock::new);
		SET_1_CABINET_WITH_DRAWERS = REGISTRY.register("set_1_cabinet_with_drawers", Set1CabinetWithDrawersBlock::new);
		SET_1_CORNER_CABINET_1 = REGISTRY.register("set_1_corner_cabinet_1", Set1CornerCabinet1Block::new);
		SET_1_CORNER_CABINET_2 = REGISTRY.register("set_1_corner_cabinet_2", Set1CornerCabinet2Block::new);
		SET_1_ISLAND_1 = REGISTRY.register("set_1_island_1", Set1Island1Block::new);
		SET_1_ISLAND_2 = REGISTRY.register("set_1_island_2", Set1Island2Block::new);
		SET_1_OVEN_MICROWAVE = REGISTRY.register("set_1_oven_microwave", Set1OvenMicrowaveBlock::new);
		SET_1_FRIDGE = REGISTRY.register("set_1_fridge", Set1FridgeBlock::new);
		SET_1_CABINET_2 = REGISTRY.register("set_1_cabinet_2", Set1Cabinet2Block::new);
		SET_1_HANGING_CABINET = REGISTRY.register("set_1_hanging_cabinet", Set1HangingCabinetBlock::new);
		SET_1_CORNER_HANGING_CABINET = REGISTRY.register("set_1_corner_hanging_cabinet", Set1CornerHangingCabinetBlock::new);
		DOCUMENT_FOLDERS = REGISTRY.register("document_folders", DocumentFoldersBlock::new);
		SET_2_CABINET_1 = REGISTRY.register("set_2_cabinet_1", Set2Cabinet1Block::new);
		SET_2_CABINET_2 = REGISTRY.register("set_2_cabinet_2", Set2Cabinet2Block::new);
		SET_2_CABINET_3 = REGISTRY.register("set_2_cabinet_3", Set2Cabinet3Block::new);
		SET_2_CABINET_WITH_DRAWERS = REGISTRY.register("set_2_cabinet_with_drawers", Set2CabinetWithDrawersBlock::new);
		SET_2_HANGING_SHELF = REGISTRY.register("set_2_hanging_shelf", Set2HangingShelfBlock::new);
		SET_2_CORNER_COUNTER = REGISTRY.register("set_2_corner_counter", Set2CornerCounterBlock::new);
		BASKETS = REGISTRY.register("baskets", BasketsBlock::new);
		OVEN = REGISTRY.register("oven", OvenBlock::new);
		INDUCTION_COOKER = REGISTRY.register("induction_cooker", InductionCookerBlock::new);
		TV_STAND_MID = REGISTRY.register("tv_stand_mid", TVStandMidBlock::new);
		TV_STAND_LEFT = REGISTRY.register("tv_stand_left", TVStandLeftBlock::new);
		TV_STAND_RIGHT = REGISTRY.register("tv_stand_right", TVStandRightBlock::new);
		TV_STAND_MID_DECORATED = REGISTRY.register("tv_stand_mid_decorated", TVStandMidDecoratedBlock::new);
		POOL_TABLE = REGISTRY.register("pool_table", PoolTableBlock::new);
		POTTED_TREE = REGISTRY.register("potted_tree", PottedTreeBlock::new);
		OUTDOOR_COUCH = REGISTRY.register("outdoor_couch", OutdoorCouchBlock::new);
		OUTDOOR_TABLE = REGISTRY.register("outdoor_table", OutdoorTableBlock::new);
		LANTERN = REGISTRY.register("lantern", LanternBlock::new);
		STREET_LANTERN_BOTTOM = REGISTRY.register("street_lantern_bottom", StreetLanternBottomBlock::new);
		STREET_LANTERN_MID = REGISTRY.register("street_lantern_mid", StreetLanternMidBlock::new);
		STREET_LATERN_TOP = REGISTRY.register("street_latern_top", StreetLaternTopBlock::new);
		CEILLING_FAN = REGISTRY.register("ceilling_fan", CeillingFanBlock::new);
		SET_1_NIGHT_TABLE = REGISTRY.register("set_1_night_table", Set1NightTableBlock::new);
		SET_1_BED = REGISTRY.register("set_1_bed", Set1BedBlock::new);
		SET_1_FOOTREST = REGISTRY.register("set_1_footrest", Set1FootrestBlock::new);
		LIGHT_GREY_COUCH_MIDDLE = REGISTRY.register("light_grey_couch_middle", LightGreyCouchMiddleBlock::new);
		LIGHT_GRAY_COUCH_LEFT = REGISTRY.register("light_gray_couch_left", LightGrayCouchLeftBlock::new);
		LIGHT_GREY_COUCH_RIGHT = REGISTRY.register("light_grey_couch_right", LightGreyCouchRightBlock::new);
		GREY_COUCH_MIDDLE = REGISTRY.register("grey_couch_middle", GreyCouchMiddleBlock::new);
		GREY_COUCH_LEFT = REGISTRY.register("grey_couch_left", GreyCouchLeftBlock::new);
		GREY_COUCH_RIGHT = REGISTRY.register("grey_couch_right", GreyCouchRightBlock::new);
		GREY_COUCH_CORNER = REGISTRY.register("grey_couch_corner", GreyCouchCornerBlock::new);
		GREY_SOFA = REGISTRY.register("grey_sofa", GreySofaBlock::new);
		SET_1_COFFE_TABLE_1_SHORT = REGISTRY.register("set_1_coffe_table_1_short", Set1CoffeTable1ShortBlock::new);
		SET_1_COFFE_TABLE_1_TALL = REGISTRY.register("set_1_coffe_table_1_tall", Set1CoffeTable1TallBlock::new);
		SET_1_COFFE_TABLE_2 = REGISTRY.register("set_1_coffe_table_2", Set1CoffeTable2Block::new);
		SET_3_COFFE_TABLE = REGISTRY.register("set_3_coffe_table", Set3CoffeTableBlock::new);
		SET_3_COFFE_TABLE_DECORATED = REGISTRY.register("set_3_coffe_table_decorated", Set3CoffeTableDecoratedBlock::new);
		SET_3TV_STAND = REGISTRY.register("set_3tv_stand", Set3tvStandBlock::new);
		SET_1_TV_STAND = REGISTRY.register("set_1_tv_stand", Set1TVStandBlock::new);
		SET_1_TV_STAND_MIDDLE = REGISTRY.register("set_1_tv_stand_middle", Set1TVStandMiddleBlock::new);
		BLACK_WALL_CLOCK = REGISTRY.register("black_wall_clock", BlackWallClockBlock::new);
		WOODEN_WALL_CLOCK = REGISTRY.register("wooden_wall_clock", WoodenWallClockBlock::new);
		SET_1_CHAIR = REGISTRY.register("set_1_chair", Set1ChairBlock::new);
		SET_1_LIVINGROOM_CABINET = REGISTRY.register("set_1_livingroom_cabinet", Set1LivingroomCabinetBlock::new);
		SET_1_LIVINGROOM_CABINET_2 = REGISTRY.register("set_1_livingroom_cabinet_2", Set1LivingroomCabinet2Block::new);
		SET_1_COFFEE_TABLE_2_MIDDLE = REGISTRY.register("set_1_coffee_table_2_middle", Set1CoffeeTable2MiddleBlock::new);
		SET_1_LIVINGROOM_HANGING_CABINET = REGISTRY.register("set_1_livingroom_hanging_cabinet", Set1LivingroomHangingCabinetBlock::new);
		KITCHEN_SET_3_CORNER_COUNTER = REGISTRY.register("kitchen_set_3_corner_counter", KitchenSet3CornerCounterBlock::new);
		KITCHEN_SET_3_CORNER_COUNTER_WITH_SINK = REGISTRY.register("kitchen_set_3_corner_counter_with_sink", KitchenSet3CornerCounterWithSinkBlock::new);
		KITCHEN_SET_3_COUNTER = REGISTRY.register("kitchen_set_3_counter", KitchenSet3CounterBlock::new);
		KITCHEN_SET_3_COUNTER_2 = REGISTRY.register("kitchen_set_3_counter_2", KitchenSet3Counter2Block::new);
		KITCHEN_SET_3_COUNTER_3 = REGISTRY.register("kitchen_set_3_counter_3", KitchenSet3Counter3Block::new);
		KITCHEN_SET_3_DISHWASHER = REGISTRY.register("kitchen_set_3_dishwasher", KitchenSet3DishwasherBlock::new);
		KITCHEN_SET_3_FRIDGE_BOTTOM = REGISTRY.register("kitchen_set_3_fridge_bottom", KitchenSet3FridgeBottomBlock::new);
		KITCHEN_SET_3_FRIDGE_TOP = REGISTRY.register("kitchen_set_3_fridge_top", KitchenSet3FridgeTopBlock::new);
		KITCHEN_SET_3_HANGING_CABINET = REGISTRY.register("kitchen_set_3_hanging_cabinet", KitchenSet3HangingCabinetBlock::new);
		KITCHEN_SET_3_OVEN_BOTTOM = REGISTRY.register("kitchen_set_3_oven_bottom", KitchenSet3OvenBottomBlock::new);
		KITCHEN_SET_3_OVEN_TOP = REGISTRY.register("kitchen_set_3_oven_top", KitchenSet3OvenTopBlock::new);
		KITCHEN_SET_3_SMALL_CORNER_HANGING_CABINET = REGISTRY.register("kitchen_set_3_small_corner_hanging_cabinet", KitchenSet3SmallCornerHangingCabinetBlock::new);
		KITCHEN_SET_3_SMALL_HANGING_CABINET = REGISTRY.register("kitchen_set_3_small_hanging_cabinet", KitchenSet3SmallHangingCabinetBlock::new);
		KITCHEN_SET_3_HANGING_CORNER_CABINET = REGISTRY.register("kitchen_set_3_hanging_corner_cabinet", KitchenSet3HangingCornerCabinetBlock::new);
		GAS_STOVE = REGISTRY.register("gas_stove", GasStoveBlock::new);
		KITCHEN_SET_3_BAR_CHAIR = REGISTRY.register("kitchen_set_3_bar_chair", KitchenSet3BarChairBlock::new);
		BEDROOMSET_1_BLACK_LOVESEAT = REGISTRY.register("bedroomset_1_black_loveseat", Bedroomset1BlackLoveseatBlock::new);
		BEDROOM_SET_1GREYDRESSERLEFT = REGISTRY.register("bedroom_set_1greydresserleft", BedroomSet1greydresserleftBlock::new);
		BEDROOM_SET_1GREYDRESSERMID = REGISTRY.register("bedroom_set_1greydressermid", BedroomSet1greydressermidBlock::new);
		BEDROOM_SET_1GREYDRESSERRIGHT = REGISTRY.register("bedroom_set_1greydresserright", BedroomSet1greydresserrightBlock::new);
		BEDROOM_SET_1GREY_SINGLE_BED = REGISTRY.register("bedroom_set_1grey_single_bed", BedroomSet1greySingleBedBlock::new);
		BEDROOM_SET_1GREY_DOUBLE_BED = REGISTRY.register("bedroom_set_1grey_double_bed", BedroomSet1greyDoubleBedBlock::new);
		BEDROOM_SET_1GREY_BUNK_BED = REGISTRY.register("bedroom_set_1grey_bunk_bed", BedroomSet1greyBunkBedBlock::new);
		BEDROOM_SET_1GREYWARDROBE = REGISTRY.register("bedroom_set_1greywardrobe", BedroomSet1greywardrobeBlock::new);
		BEDROOM_SET_1GREYLOVESEAT = REGISTRY.register("bedroom_set_1greyloveseat", BedroomSet1greyloveseatBlock::new);
		BEDROOM_SET_1GREY_NIGHTSTAND_1 = REGISTRY.register("bedroom_set_1grey_nightstand_1", BedroomSet1greyNightstand1Block::new);
		BEDROOM_SET_1GREY_NIGHTSTAND_2 = REGISTRY.register("bedroom_set_1grey_nightstand_2", BedroomSet1greyNightstand2Block::new);
		BEDROOM_SET_1WENGEBUNKBED = REGISTRY.register("bedroom_set_1wengebunkbed", BedroomSet1wengebunkbedBlock::new);
		BEDROOM_SET_1WENGE_DOUBLE_BED = REGISTRY.register("bedroom_set_1wenge_double_bed", BedroomSet1wengeDoubleBedBlock::new);
		BEDROOM_SET_1WENGE_SINGLE_BED = REGISTRY.register("bedroom_set_1wenge_single_bed", BedroomSet1wengeSingleBedBlock::new);
		BEDROOM_SET_1WENGEDRESSERMID = REGISTRY.register("bedroom_set_1wengedressermid", BedroomSet1wengedressermidBlock::new);
		BEDROOM_SET_1WENGEDRESSERLEFT = REGISTRY.register("bedroom_set_1wengedresserleft", BedroomSet1wengedresserleftBlock::new);
		BEDROOM_SET_1WENGEDRESSERRIGHT = REGISTRY.register("bedroom_set_1wengedresserright", BedroomSet1wengedresserrightBlock::new);
		BEDROOM_SET_1WENGEWARDROBE = REGISTRY.register("bedroom_set_1wengewardrobe", BedroomSet1wengewardrobeBlock::new);
		BEDROOM_SET_1WENGENIGHTSTAND_1 = REGISTRY.register("bedroom_set_1wengenightstand_1", BedroomSet1wengenightstand1Block::new);
		BEDROOM_SET_1WENGENIGHSTAND_2 = REGISTRY.register("bedroom_set_1wengenighstand_2", BedroomSet1wengenighstand2Block::new);
		BEDROOM_SET_1WHITEBUNKBED = REGISTRY.register("bedroom_set_1whitebunkbed", BedroomSet1whitebunkbedBlock::new);
		BEDROOM_SET_1WHITE_DOUBLEBED = REGISTRY.register("bedroom_set_1white_doublebed", BedroomSet1whiteDoublebedBlock::new);
		BEDROOM_SET_1WHITE_SINGLEBED = REGISTRY.register("bedroom_set_1white_singlebed", BedroomSet1whiteSinglebedBlock::new);
		BEDROOM_SET_1WHITEDRESSERLEFT = REGISTRY.register("bedroom_set_1whitedresserleft", BedroomSet1whitedresserleftBlock::new);
		BEDROOM_SET_1WHITEDRESSERMID = REGISTRY.register("bedroom_set_1whitedressermid", BedroomSet1whitedressermidBlock::new);
		BEDROOM_SET_1WHITEDRESSERRIGHT = REGISTRY.register("bedroom_set_1whitedresserright", BedroomSet1whitedresserrightBlock::new);
		BEDROOM_SET_1WHITEWARDROBE = REGISTRY.register("bedroom_set_1whitewardrobe", BedroomSet1whitewardrobeBlock::new);
		BEDROOM_SET_1WHITELOVESEAT = REGISTRY.register("bedroom_set_1whiteloveseat", BedroomSet1whiteloveseatBlock::new);
		BEDROOM_SET_1WHITENIGHTSTAND_1 = REGISTRY.register("bedroom_set_1whitenightstand_1", BedroomSet1whitenightstand1Block::new);
		BEDROOM_SET_1WHITENIGHSTAND_2 = REGISTRY.register("bedroom_set_1whitenighstand_2", BedroomSet1whitenighstand2Block::new);
		OFFICE_SET_1_DESK_2_MID = REGISTRY.register("office_set_1_desk_2_mid", OfficeSet1Desk2MidBlock::new);
		OFFICE_SET_1_DESK_2_SIDE = REGISTRY.register("office_set_1_desk_2_side", OfficeSet1Desk2SideBlock::new);
		OFFICE_SET_1_DESK_2_SIDE_VAR_2 = REGISTRY.register("office_set_1_desk_2_side_var_2", OfficeSet1Desk2SideVar2Block::new);
		OFFICE_SET_1_BOOKSHELF_VAR_1_BOTTOM = REGISTRY.register("office_set_1_bookshelf_var_1_bottom", OfficeSet1BookshelfVar1BottomBlock::new);
		OFFICE_SET_1_BOOKSHELF_VAR_1_TOP = REGISTRY.register("office_set_1_bookshelf_var_1_top", OfficeSet1BookshelfVar1TopBlock::new);
		OFFICE_SET_1_SHELF_VAR_1_BOTTOM = REGISTRY.register("office_set_1_shelf_var_1_bottom", OfficeSet1ShelfVar1BottomBlock::new);
		OFFICE_SET_1_SHELF_VAR_1_TOP = REGISTRY.register("office_set_1_shelf_var_1_top", OfficeSet1ShelfVar1TopBlock::new);
		OFFICE_SET_1_SHELF_VAR_2_BOTTOM = REGISTRY.register("office_set_1_shelf_var_2_bottom", OfficeSet1ShelfVar2BottomBlock::new);
		OFFICE_SET_1_SHELF_VAR_2_TOP = REGISTRY.register("office_set_1_shelf_var_2_top", OfficeSet1ShelfVar2TopBlock::new);
		OFFICE_SET_1_DESK_1_CABINET = REGISTRY.register("office_set_1_desk_1_cabinet", OfficeSet1Desk1CabinetBlock::new);
		OFFICE_SET_1_DESK_1_CABINET_VAR_2 = REGISTRY.register("office_set_1_desk_1_cabinet_var_2", OfficeSet1Desk1CabinetVar2Block::new);
		OFFICE_SET_1_DESK_1_CABINET_VAR_3 = REGISTRY.register("office_set_1_desk_1_cabinet_var_3", OfficeSet1Desk1CabinetVar3Block::new);
		OFFICE_SET_1_DESK_1_CABINET_VAR_4 = REGISTRY.register("office_set_1_desk_1_cabinet_var_4", OfficeSet1Desk1CabinetVar4Block::new);
		OFFICE_SET_1_DESK_1_LEFT = REGISTRY.register("office_set_1_desk_1_left", OfficeSet1Desk1LeftBlock::new);
		OFFICE_SET_1_DESK_1_LEFT_VAR_2 = REGISTRY.register("office_set_1_desk_1_left_var_2", OfficeSet1Desk1LeftVar2Block::new);
		OFFICE_SET_1_DESK_1_LEFT_VAR_3 = REGISTRY.register("office_set_1_desk_1_left_var_3", OfficeSet1Desk1LeftVar3Block::new);
		OFFICE_SET_1_DESK_1_MIDDLE = REGISTRY.register("office_set_1_desk_1_middle", OfficeSet1Desk1MiddleBlock::new);
		OFFICE_SET_1_DESK_1_RIGHT = REGISTRY.register("office_set_1_desk_1_right", OfficeSet1Desk1RightBlock::new);
		OFFICE_SET_1_DESK_1_RIGHT_VAR_2 = REGISTRY.register("office_set_1_desk_1_right_var_2", OfficeSet1Desk1RightVar2Block::new);
		OFFICE_SET_1_DESK_1_RIGHT_VAR_3 = REGISTRY.register("office_set_1_desk_1_right_var_3", OfficeSet1Desk1RightVar3Block::new);
		OFFICE_SET_1_CHAIR = REGISTRY.register("office_set_1_chair", OfficeSet1ChairBlock::new);
		OFFICE_SET_1_DESK_LAMP = REGISTRY.register("office_set_1_desk_lamp", OfficeSet1DeskLampBlock::new);
		BLACK_BENCH = REGISTRY.register("black_bench", BenchBlock::new);
		WHITE_BENCH = REGISTRY.register("white_bench", WhiteBenchBlock::new);
		CARPET_2 = REGISTRY.register("carpet_2", Carpet2Block::new);
		CARPET_3 = REGISTRY.register("carpet_3", Carpet3Block::new);
		CARPET_4 = REGISTRY.register("carpet_4", Carpet4Block::new);
		WHITE_BOARD = REGISTRY.register("white_board", WhiteBoardBlock::new);
		STANDING_WHITE_BOARD = REGISTRY.register("standing_white_board", StandingWhiteBoardBlock::new);
		CORK_BOARD = REGISTRY.register("cork_board", CorkBoardBlock::new);
		MODERN_PAINTING = REGISTRY.register("modern_painting", ModernPaintingBlock::new);
		MODERN_PAINTING_2 = REGISTRY.register("modern_painting_2", ModernPainting2Block::new);
		WHITE_CURTAIN = REGISTRY.register("white_curtain", WhiteCurtainBlock::new);
		WHITE_CURTAIN_LEFT = REGISTRY.register("white_curtain_left", WhiteCurtainLeftBlock::new);
		WHITE_CURTAIN_RIGHT = REGISTRY.register("white_curtain_right", WhiteCurtainRightBlock::new);
		RED_CURTAIN = REGISTRY.register("red_curtain", RedCurtainBlock::new);
		RED_CURTAIN_LEFT = REGISTRY.register("red_curtain_left", RedCurtainLeftBlock::new);
		RED_CURTAIN_RIGHT = REGISTRY.register("red_curtain_right", RedCurtainRightBlock::new);
		CURTAIN_RACK = REGISTRY.register("curtain_rack", CurtainRackBlock::new);
		BLACK_CURTAIN = REGISTRY.register("black_curtain", BlackCurtainBlock::new);
		BLACK_CURTAIN_LEFT = REGISTRY.register("black_curtain_left", BlackCurtainLeftBlock::new);
		BLACK_CURTAIN_RIGHT = REGISTRY.register("black_curtain_right", BlackCurtainRightBlock::new);
		GREY_CURTAIN = REGISTRY.register("grey_curtain", GreyCurtainBlock::new);
		GREY_CURTAIN_LEFT = REGISTRY.register("grey_curtain_left", GreyCurtainLeftBlock::new);
		GREY_CURTAIN_RIGHT = REGISTRY.register("grey_curtain_right", GreyCurtainRightBlock::new);
		BLUE_CURTAIN = REGISTRY.register("blue_curtain", BlueCurtainBlock::new);
		BLUE_CURTAIN_LEFT = REGISTRY.register("blue_curtain_left", BlueCurtainLeftBlock::new);
		BLUE_CURTAIN_RIGHT = REGISTRY.register("blue_curtain_right", BlueCurtainRightBlock::new);
		GREEN_CURTAIN = REGISTRY.register("green_curtain", GreenCurtainBlock::new);
		GREEN_CURTAIN_LEFT = REGISTRY.register("green_curtain_left", GreenCurtainLeftBlock::new);
		GREEN_CURTAIN_RIGHT = REGISTRY.register("green_curtain_right", GreenCurtainRightBlock::new);
		FOYER_WALL_UNIT_BOTTOM = REGISTRY.register("foyer_wall_unit_bottom", FoyerWallUnitBottomBlock::new);
		FOYER_WALL_UNIT_TOP = REGISTRY.register("foyer_wall_unit_top", FoyerWallUnitTopBlock::new);
		WHITE_WOOD_FOYER_WALL_UNIT = REGISTRY.register("white_wood_foyer_wall_unit", WhiteWoodFoyerWallUnitBlock::new);
		WHITE_WOOD_FOYER_WALL_UNIT_TOP = REGISTRY.register("white_wood_foyer_wall_unit_top", WhiteWoodFoyerWallUnitTopBlock::new);
		BLACK_FOYER_WALL_UNIT = REGISTRY.register("black_foyer_wall_unit", BlackFoyerWallUnitBlock::new);
		BLACK_FOYER_WALL_UNIT_TOP = REGISTRY.register("black_foyer_wall_unit_top", BlackFoyerWallUnitTopBlock::new);
		WHITE_ARMCHAIR = REGISTRY.register("white_armchair", WhiteArmchairBlock::new);
		BLACK_ARMCHAIR = REGISTRY.register("black_armchair", BlackArmchairBlock::new);
		SMALL_TABLE = REGISTRY.register("small_table", SmallTableBlock::new);
		SMALL_CHANDELIER = REGISTRY.register("small_chandelier", SmallChandelierBlock::new);
		SMALL_CEILING_LAMP = REGISTRY.register("small_ceiling_lamp", SmallCeilingLampBlock::new);
		BIG_CEILING_LIGHT = REGISTRY.register("big_ceiling_light", BigCeilingLightBlock::new);
		BIG_CEILING_LAMP = REGISTRY.register("big_ceiling_lamp", BigCeilingLampBlock::new);
		BATHROOM_RADIATOR = REGISTRY.register("bathroom_radiator", BathroomRadiatorBlock::new);
		BATHROOM_SHELF_02 = REGISTRY.register("bathroom_shelf_02", BathroomShelf02Block::new);
		BOWL = REGISTRY.register("bowl", BowlBlock::new);
		CHOPPING_BOARD = REGISTRY.register("chopping_board", ChoppingBoardBlock::new);
		COFFEE_TABLE_04 = REGISTRY.register("coffee_table_04", CoffeeTable04Block::new);
		CRIB = REGISTRY.register("crib", CribBlock::new);
		FORK = REGISTRY.register("fork", ForkBlock::new);
		KNIFE = REGISTRY.register("knife", KnifeBlock::new);
		KNIFE_STAND = REGISTRY.register("knife_stand", KnifeStandBlock::new);
		LAMP_03 = REGISTRY.register("lamp_03", Lamp03Block::new);
		MUG = REGISTRY.register("mug", MugBlock::new);
		PAINTING_05 = REGISTRY.register("painting_05", Painting05Block::new);
		PLATE = REGISTRY.register("plate", PlateBlock::new);
		POTTED_CACTUS = REGISTRY.register("potted_cactus", PottedCactusBlock::new);
		POUF = REGISTRY.register("pouf", PoufBlock::new);
		SEASONING_RACK = REGISTRY.register("seasoning_rack", SeasoningRackBlock::new);
		SPOON = REGISTRY.register("spoon", SpoonBlock::new);
		WALL_LAMP = REGISTRY.register("wall_lamp", WallLampBlock::new);
		WALL_LAMP_2 = REGISTRY.register("wall_lamp_2", WallLamp2Block::new);
		WINDOW_BLINDS = REGISTRY.register("window_blinds", WindowBlindsBlock::new);
		PAINTING_03 = REGISTRY.register("painting_03", Painting03Block::new);
		PAINTING_04 = REGISTRY.register("painting_04", Painting04Block::new);
		BOXES = REGISTRY.register("boxes", BoxesBlock::new);
		COAT_HANGER = REGISTRY.register("coat_hanger", CoatHangerBlock::new);
		DOOR_MAT = REGISTRY.register("door_mat", DoorMatBlock::new);
		ELECTRIC_GUITAR_BLACK = REGISTRY.register("electric_guitar_black", ElectricGuitarBlackBlock::new);
		ELECTRIC_GUITAR_WITH_STAND = REGISTRY.register("electric_guitar_with_stand", ElectricGuitarWithStandBlock::new);
		ENTRYWAY_CARPET = REGISTRY.register("entryway_carpet", EntrywayCarpetBlock::new);
		FOYER_BENCH = REGISTRY.register("foyer_bench", FoyerBenchBlock::new);
		FOYER_BENCH_DARK = REGISTRY.register("foyer_bench_dark", FoyerBenchDarkBlock::new);
		FOYER_BENCH_WHITE = REGISTRY.register("foyer_bench_white", FoyerBenchWhiteBlock::new);
		FOYER_BENCH_WENGE = REGISTRY.register("foyer_bench_wenge", FoyerBenchWengeBlock::new);
		PAIR_OF_BOOTS = REGISTRY.register("pair_of_boots", PairOfBootsBlock::new);
		PAIR_OF_BOOTS_2 = REGISTRY.register("pair_of_boots_2", PairOfBoots2Block::new);
		PAIR_OF_BOOTS_3 = REGISTRY.register("pair_of_boots_3", PairOfBoots3Block::new);
		PAIR_OF_BOOTS_4 = REGISTRY.register("pair_of_boots_4", PairOfBoots4Block::new);
		PAIR_OF_BOOTS_5 = REGISTRY.register("pair_of_boots_5", PairOfBoots5Block::new);
		PAIR_OF_BOOTS_6 = REGISTRY.register("pair_of_boots_6", PairOfBoots6Block::new);
		SHOE_RACK = REGISTRY.register("shoe_rack", ShoeRackBlock::new);
		SHOE_RACK_2 = REGISTRY.register("shoe_rack_2", ShoeRack2Block::new);
		SHOE_RACK_3 = REGISTRY.register("shoe_rack_3", ShoeRack3Block::new);
		TALL_MIRROR = REGISTRY.register("tall_mirror", TallMirrorBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	@Mod.EventBusSubscriber
	public static class BlocksHandler {
		@SubscribeEvent
		public static void onNoteBlockPlay(NoteBlockEvent.Play event) {
			Block below = event.getWorld().getBlockState(event.getPos().down()).getBlock();
			if (below == MdmModBlocks.BLACK_MODERN_FRIDGE_1.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.LEAFLESS_BAMBOO_DECORATION_1.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.LEAFLESS_BAMBOO_DECORATION_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.LEAFLESS_BAMBOO_DECORATION_3.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLACK_MODER_STAIRS.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.WHITE_MODERN_STAIRS.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.RED_MODERN_STAIRS.get()) {
				event.setInstrument(NoteBlockInstrument.BASS);
			} else if (below == MdmModBlocks.BLUE_MODERN_STAIRS.get()) {
				event.setInstrument(NoteBlockInstrument.BASS);
			} else if (below == MdmModBlocks.GREEN_MODERN_STAIRS.get()) {
				event.setInstrument(NoteBlockInstrument.BASS);
			} else if (below == MdmModBlocks.STEEL_SHELF.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLACK_LAMP.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.COUCHLEFT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.COUCHMIDDLE.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.COUCH_RIGHT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.COUCH_CORNER.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SOFA.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.HAND_SOAP_AND_CREAM_SET.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.TOILET_PAPER_ROLL.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SOAP_BAR.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.TOILET.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BATHROOM_SINK.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BATHROOM_SINK_WITH_SHELF.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLACK_WASHBASIN_TAP.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.WHITE_BATHROOM_SHELF.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.RING_LAMP.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.WHITE_BATHTUB.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.TOWEL_SET_1.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.TOOTHBRUSHES.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.CHLOTHESBIN.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BATHROOM_STAND.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.PILE_OF_TOWELS.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.WALKIN_SHOWER.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.RAIN_SHOWER.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLACK_OFFICE_DESK.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLACK_DESK_EXTENSION_1.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLACK_DESK_EXTENSION_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLACK_DESK_EXTENSION_3.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_CABINET_1.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_CABINET_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_CABINET_3.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SHELF.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BATHROOM_MIRROR.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.MODERN_DESK_1.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.MODERN_DESK_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SHELF.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.HANGING_SHELF.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLACK_DESK_LAMP.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.MODERN_LAMP_1.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.MODERN_DESK_LAMP_1.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.MODERN_CHANDELIER_1.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_CABINET.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_CABINET_WITH_DRAWERS.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_CORNER_CABINET_1.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_CORNER_CABINET_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_ISLAND_1.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_ISLAND_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_OVEN_MICROWAVE.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_FRIDGE.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_CABINET_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_HANGING_CABINET.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_CORNER_HANGING_CABINET.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_2_CABINET_1.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_2_CABINET_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_2_CABINET_3.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_2_CABINET_WITH_DRAWERS.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_2_HANGING_SHELF.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_2_CORNER_COUNTER.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BASKETS.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OVEN.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.INDUCTION_COOKER.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.TV_STAND_MID.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.TV_STAND_LEFT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.TV_STAND_RIGHT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.TV_STAND_MID_DECORATED.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.POOL_TABLE.get()) {
				event.setInstrument(NoteBlockInstrument.BASS);
			} else if (below == MdmModBlocks.POTTED_TREE.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OUTDOOR_COUCH.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OUTDOOR_TABLE.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.LANTERN.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.STREET_LANTERN_BOTTOM.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.STREET_LANTERN_MID.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.STREET_LATERN_TOP.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.CEILLING_FAN.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_NIGHT_TABLE.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_BED.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_FOOTREST.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.LIGHT_GREY_COUCH_MIDDLE.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.LIGHT_GRAY_COUCH_LEFT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.LIGHT_GREY_COUCH_RIGHT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.GREY_COUCH_MIDDLE.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.GREY_COUCH_LEFT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.GREY_COUCH_RIGHT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.GREY_COUCH_CORNER.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.GREY_SOFA.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_COFFE_TABLE_1_SHORT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_COFFE_TABLE_1_TALL.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_COFFE_TABLE_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_3_COFFE_TABLE.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_3_COFFE_TABLE_DECORATED.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_3TV_STAND.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_TV_STAND.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_TV_STAND_MIDDLE.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLACK_WALL_CLOCK.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.WOODEN_WALL_CLOCK.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_CHAIR.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_LIVINGROOM_CABINET.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_LIVINGROOM_CABINET_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_COFFEE_TABLE_2_MIDDLE.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SET_1_LIVINGROOM_HANGING_CABINET.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.KITCHEN_SET_3_CORNER_COUNTER.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.KITCHEN_SET_3_CORNER_COUNTER_WITH_SINK.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.KITCHEN_SET_3_COUNTER.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.KITCHEN_SET_3_COUNTER_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.KITCHEN_SET_3_COUNTER_3.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.KITCHEN_SET_3_DISHWASHER.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.KITCHEN_SET_3_FRIDGE_BOTTOM.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.KITCHEN_SET_3_FRIDGE_TOP.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.KITCHEN_SET_3_HANGING_CABINET.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.KITCHEN_SET_3_OVEN_BOTTOM.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.KITCHEN_SET_3_OVEN_TOP.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.KITCHEN_SET_3_SMALL_CORNER_HANGING_CABINET.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.KITCHEN_SET_3_SMALL_HANGING_CABINET.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.KITCHEN_SET_3_HANGING_CORNER_CABINET.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.GAS_STOVE.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.KITCHEN_SET_3_BAR_CHAIR.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOMSET_1_BLACK_LOVESEAT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1GREYDRESSERLEFT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1GREYDRESSERMID.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1GREYDRESSERRIGHT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1GREY_SINGLE_BED.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1GREY_DOUBLE_BED.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1GREY_BUNK_BED.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1GREYWARDROBE.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1GREYLOVESEAT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1GREY_NIGHTSTAND_1.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1GREY_NIGHTSTAND_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WENGEBUNKBED.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WENGE_DOUBLE_BED.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WENGE_SINGLE_BED.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WENGEDRESSERMID.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WENGEDRESSERLEFT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WENGEDRESSERRIGHT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WENGEWARDROBE.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WENGENIGHTSTAND_1.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WENGENIGHSTAND_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WHITEBUNKBED.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WHITE_DOUBLEBED.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WHITE_SINGLEBED.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WHITEDRESSERLEFT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WHITEDRESSERMID.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WHITEDRESSERRIGHT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WHITEWARDROBE.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WHITELOVESEAT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WHITENIGHTSTAND_1.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BEDROOM_SET_1WHITENIGHSTAND_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_DESK_2_MID.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_DESK_2_SIDE.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_DESK_2_SIDE_VAR_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_BOOKSHELF_VAR_1_BOTTOM.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_BOOKSHELF_VAR_1_TOP.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_SHELF_VAR_1_BOTTOM.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_SHELF_VAR_1_TOP.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_SHELF_VAR_2_BOTTOM.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_SHELF_VAR_2_TOP.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_DESK_1_CABINET.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_DESK_1_CABINET_VAR_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_DESK_1_CABINET_VAR_3.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_DESK_1_CABINET_VAR_4.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_DESK_1_LEFT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_DESK_1_LEFT_VAR_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_DESK_1_LEFT_VAR_3.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_DESK_1_MIDDLE.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_DESK_1_RIGHT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_DESK_1_RIGHT_VAR_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_DESK_1_RIGHT_VAR_3.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_CHAIR.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.OFFICE_SET_1_DESK_LAMP.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLACK_BENCH.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.WHITE_BENCH.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.CARPET_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.CARPET_3.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.CARPET_4.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.WHITE_BOARD.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.STANDING_WHITE_BOARD.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.CORK_BOARD.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.MODERN_PAINTING.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.MODERN_PAINTING_2.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.WHITE_CURTAIN.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.WHITE_CURTAIN_LEFT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.WHITE_CURTAIN_RIGHT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.RED_CURTAIN.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.RED_CURTAIN_LEFT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.RED_CURTAIN_RIGHT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.CURTAIN_RACK.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLACK_CURTAIN.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLACK_CURTAIN_LEFT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLACK_CURTAIN_RIGHT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.GREY_CURTAIN.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.GREY_CURTAIN_LEFT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.GREY_CURTAIN_RIGHT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLUE_CURTAIN.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLUE_CURTAIN_LEFT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLUE_CURTAIN_RIGHT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.GREEN_CURTAIN.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.GREEN_CURTAIN_LEFT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.GREEN_CURTAIN_RIGHT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.FOYER_WALL_UNIT_BOTTOM.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.FOYER_WALL_UNIT_TOP.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.WHITE_WOOD_FOYER_WALL_UNIT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.WHITE_WOOD_FOYER_WALL_UNIT_TOP.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLACK_FOYER_WALL_UNIT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLACK_FOYER_WALL_UNIT_TOP.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.WHITE_ARMCHAIR.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BLACK_ARMCHAIR.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SMALL_TABLE.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SMALL_CHANDELIER.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.SMALL_CEILING_LAMP.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BIG_CEILING_LIGHT.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			} else if (below == MdmModBlocks.BIG_CEILING_LAMP.get()) {
				event.setInstrument(NoteBlockInstrument.BASEDRUM);
			}
		}
	}
}