package com.cookiecraftmods.mdm.block;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.IBlockReader;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Rotation;
import net.minecraft.util.Mirror;
import net.minecraft.util.Direction;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.state.StateContainer;
import net.minecraft.state.DirectionProperty;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.block.material.Material;
import net.minecraft.block.SoundType;
import net.minecraft.block.HorizontalBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Block;

import com.google.common.collect.ImmutableMap;

public class GreenModernStairsBlock extends Block {
	public static final DirectionProperty FACING = HorizontalBlock.HORIZONTAL_FACING;
	private final ImmutableMap<BlockState, VoxelShape> shapes = this.makeShapes();

	public GreenModernStairsBlock() {
		super(Block.Properties.create(Material.REDSTONE_LIGHT).sound(SoundType.WOOD).hardnessAndResistance(1f, 10f));
		this.setDefaultState(this.stateContainer.getBaseState().with(FACING, Direction.NORTH));
	}

	@Override
	public boolean isSolid(BlockState state) {
		return false;
	}

	private ImmutableMap<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			switch (state.get(FACING)) {
				case NORTH :
					return VoxelShapes.or(makeCuboidShape(0, 8, 0, 16, 9, 7), makeCuboidShape(0, 16, 9, 16, 17, 16), makeCuboidShape(6.5, 0, 0, 9.5, 1, 6), makeCuboidShape(6.5, 1, 2.5, 9.5, 8, 3.5), makeCuboidShape(6.5, 7, 15, 9.5, 16, 16),
							makeCuboidShape(6.5, 9.75, 12.5, 9.5, 17.75, 13.5), makeCuboidShape(6.5, 6, 3.5, 9.5, 7, 16));
				case EAST :
					return VoxelShapes.or(makeCuboidShape(9, 8, 0, 16, 9, 16), makeCuboidShape(0, 16, 0, 7, 17, 16), makeCuboidShape(10, 0, 6.5, 16, 1, 9.5), makeCuboidShape(12.5, 1, 6.5, 13.5, 8, 9.5), makeCuboidShape(0, 7, 6.5, 1, 16, 9.5),
							makeCuboidShape(2.5, 9.75, 6.5, 3.5, 17.75, 9.5), makeCuboidShape(0, 6, 6.5, 12.5, 7, 9.5));
				case WEST :
					return VoxelShapes.or(makeCuboidShape(0, 8, 0, 7, 9, 16), makeCuboidShape(9, 16, 0, 16, 17, 16), makeCuboidShape(0, 0, 6.5, 6, 1, 9.5), makeCuboidShape(2.5, 1, 6.5, 3.5, 8, 9.5), makeCuboidShape(15, 7, 6.5, 16, 16, 9.5),
							makeCuboidShape(12.5, 9.75, 6.5, 13.5, 17.75, 9.5), makeCuboidShape(3.5, 6, 6.5, 16, 7, 9.5));
				default :
					return VoxelShapes.or(makeCuboidShape(0, 8, 9, 16, 9, 16), makeCuboidShape(0, 16, 0, 16, 17, 7), makeCuboidShape(6.5, 0, 10, 9.5, 1, 16), makeCuboidShape(6.5, 1, 12.5, 9.5, 8, 13.5), makeCuboidShape(6.5, 7, 0, 9.5, 16, 1),
							makeCuboidShape(6.5, 9.75, 2.5, 9.5, 17.75, 3.5), makeCuboidShape(6.5, 6, 0, 9.5, 7, 12.5));
			}
		});
	}

	private ImmutableMap<BlockState, VoxelShape> getShapeForEachState(Function<BlockState, VoxelShape> func) {
		return stateContainer.getValidStates().stream().collect(ImmutableMap.toImmutableMap(Function.identity(), func));
	}

	@Override
	public VoxelShape getShape(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext context) {
		return shapes.get(state);
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public BlockRenderLayer getRenderLayer() {
		return BlockRenderLayer.CUTOUT;
	}

	@Override
	public boolean isNormalCube(BlockState state, IBlockReader worldIn, BlockPos pos) {
		return false;
	}

	@Override
	public VoxelShape getRaytraceShape(BlockState state, IBlockReader world, BlockPos pos) {
		return VoxelShapes.empty();
	}

	@Override
	protected void fillStateContainer(StateContainer.Builder<Block, BlockState> builder) {
		super.fillStateContainer(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockItemUseContext context) {
		return super.getStateForPlacement(context).with(FACING, context.getPlacementHorizontalFacing().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.with(FACING, rot.rotate(state.get(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.toRotation(state.get(FACING)));
	}

	@Override
	public boolean isFlammable(BlockState state, IBlockReader world, BlockPos pos, Direction face) {
		return true;
	}
}