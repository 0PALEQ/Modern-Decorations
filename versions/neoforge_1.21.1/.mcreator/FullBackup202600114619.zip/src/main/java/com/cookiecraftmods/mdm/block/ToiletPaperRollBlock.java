package com.cookiecraftmods.mdm.block;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.IBlockReader;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Rotation;
import net.minecraft.util.Mirror;
import net.minecraft.util.Direction;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.state.StateContainer;
import net.minecraft.state.DirectionProperty;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.block.material.Material;
import net.minecraft.block.SoundType;
import net.minecraft.block.HorizontalBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Block;

import com.google.common.collect.ImmutableMap;

public class ToiletPaperRollBlock extends Block {
	public static final DirectionProperty FACING = HorizontalBlock.HORIZONTAL_FACING;
	private final ImmutableMap<BlockState, VoxelShape> shapes = this.makeShapes();

	public ToiletPaperRollBlock() {
		super(Block.Properties.create(Material.REDSTONE_LIGHT).sound(SoundType.CROP).hardnessAndResistance(1f, 10f));
		this.setDefaultState(this.stateContainer.getBaseState().with(FACING, Direction.NORTH));
	}

	@Override
	public boolean isSolid(BlockState state) {
		return false;
	}

	private ImmutableMap<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			switch (state.get(FACING)) {
				case NORTH :
					return VoxelShapes.or(makeCuboidShape(4.5, 13, 13, 5.5, 14, 16), makeCuboidShape(10.5, 13, 13, 11.5, 14, 16), makeCuboidShape(6, 12, 12, 10, 15, 15), makeCuboidShape(6, 10, 11.975, 10, 15, 12),
							makeCuboidShape(5.5, 13, 13, 10.5, 14, 14));
				case EAST :
					return VoxelShapes.or(makeCuboidShape(0, 13, 4.5, 3, 14, 5.5), makeCuboidShape(0, 13, 10.5, 3, 14, 11.5), makeCuboidShape(1, 12, 6, 4, 15, 10), makeCuboidShape(4, 10, 6, 4.025, 15, 10), makeCuboidShape(2, 13, 5.5, 3, 14, 10.5));
				case WEST :
					return VoxelShapes.or(makeCuboidShape(13, 13, 10.5, 16, 14, 11.5), makeCuboidShape(13, 13, 4.5, 16, 14, 5.5), makeCuboidShape(12, 12, 6, 15, 15, 10), makeCuboidShape(11.975, 10, 6, 12, 15, 10),
							makeCuboidShape(13, 13, 5.5, 14, 14, 10.5));
				default :
					return VoxelShapes.or(makeCuboidShape(10.5, 13, 0, 11.5, 14, 3), makeCuboidShape(4.5, 13, 0, 5.5, 14, 3), makeCuboidShape(6, 12, 1, 10, 15, 4), makeCuboidShape(6, 10, 4, 10, 15, 4.025), makeCuboidShape(5.5, 13, 2, 10.5, 14, 3));
			}
		});
	}

	private ImmutableMap<BlockState, VoxelShape> getShapeForEachState(Function<BlockState, VoxelShape> func) {
		return stateContainer.getValidStates().stream().collect(ImmutableMap.toImmutableMap(Function.identity(), func));
	}

	@Override
	public VoxelShape getShape(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext context) {
		return shapes.get(state);
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public BlockRenderLayer getRenderLayer() {
		return BlockRenderLayer.CUTOUT;
	}

	@Override
	public boolean isNormalCube(BlockState state, IBlockReader worldIn, BlockPos pos) {
		return false;
	}

	@Override
	public VoxelShape getRaytraceShape(BlockState state, IBlockReader world, BlockPos pos) {
		return VoxelShapes.empty();
	}

	@Override
	protected void fillStateContainer(StateContainer.Builder<Block, BlockState> builder) {
		super.fillStateContainer(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockItemUseContext context) {
		return super.getStateForPlacement(context).with(FACING, context.getPlacementHorizontalFacing().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.with(FACING, rot.rotate(state.get(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.toRotation(state.get(FACING)));
	}
}