package com.cookiecraftmods.mdm.block;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.IBlockReader;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Rotation;
import net.minecraft.util.Mirror;
import net.minecraft.util.Direction;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.state.StateContainer;
import net.minecraft.state.DirectionProperty;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.block.material.Material;
import net.minecraft.block.HorizontalBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Block;

import com.google.common.collect.ImmutableMap;

public class BlackModernFridge1Block extends Block {
	public static final DirectionProperty FACING = HorizontalBlock.HORIZONTAL_FACING;
	private final ImmutableMap<BlockState, VoxelShape> shapes = this.makeShapes();

	public BlackModernFridge1Block() {
		super(Block.Properties.create(Material.REDSTONE_LIGHT).hardnessAndResistance(1f, 10f));
		this.setDefaultState(this.stateContainer.getBaseState().with(FACING, Direction.NORTH));
	}

	@Override
	public boolean isSolid(BlockState state) {
		return false;
	}

	private ImmutableMap<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			switch (state.get(FACING)) {
				case NORTH :
					return VoxelShapes.or(makeCuboidShape(0, 0, 3, 16, 32, 15), makeCuboidShape(1, 1, 2.5, 6.5, 31, 3), makeCuboidShape(7, 1, 2.5, 15, 31, 3), makeCuboidShape(0.975, 0.975, 2.975, 6.525, 31.025, 3),
							makeCuboidShape(6.975, 0.975, 2.975, 15.025, 31.025, 3), makeCuboidShape(5.75, 6, 2.25, 6, 23, 2.5), makeCuboidShape(5.5, 6, 2, 6, 23, 2.25), makeCuboidShape(7.5, 6, 2.25, 7.75, 23, 2.5),
							makeCuboidShape(7.5, 6, 2, 8, 23, 2.25), makeCuboidShape(1, 1, 15, 15, 31, 15.5), makeCuboidShape(13.25, 0.15, 15, 15.75, 0.825, 15.025));
				case EAST :
					return VoxelShapes.or(makeCuboidShape(1, 0, 0, 13, 32, 16), makeCuboidShape(13, 1, 1, 13.5, 31, 6.5), makeCuboidShape(13, 1, 7, 13.5, 31, 15), makeCuboidShape(13, 0.975, 0.975, 13.025, 31.025, 6.525),
							makeCuboidShape(13, 0.975, 6.975, 13.025, 31.025, 15.025), makeCuboidShape(13.5, 6, 5.75, 13.75, 23, 6), makeCuboidShape(13.75, 6, 5.5, 14, 23, 6), makeCuboidShape(13.5, 6, 7.5, 13.75, 23, 7.75),
							makeCuboidShape(13.75, 6, 7.5, 14, 23, 8), makeCuboidShape(0.5, 1, 1, 1, 31, 15), makeCuboidShape(0.975, 0.15, 13.25, 1, 0.825, 15.75));
				case WEST :
					return VoxelShapes.or(makeCuboidShape(3, 0, 0, 15, 32, 16), makeCuboidShape(2.5, 1, 9.5, 3, 31, 15), makeCuboidShape(2.5, 1, 1, 3, 31, 9), makeCuboidShape(2.975, 0.975, 9.475, 3, 31.025, 15.025),
							makeCuboidShape(2.975, 0.975, 0.975, 3, 31.025, 9.025), makeCuboidShape(2.25, 6, 10, 2.5, 23, 10.25), makeCuboidShape(2, 6, 10, 2.25, 23, 10.5), makeCuboidShape(2.25, 6, 8.25, 2.5, 23, 8.5),
							makeCuboidShape(2, 6, 8, 2.25, 23, 8.5), makeCuboidShape(15, 1, 1, 15.5, 31, 15), makeCuboidShape(15, 0.15, 0.25, 15.025, 0.825, 2.75));
				default :
					return VoxelShapes.or(makeCuboidShape(0, 0, 1, 16, 32, 13), makeCuboidShape(9.5, 1, 13, 15, 31, 13.5), makeCuboidShape(1, 1, 13, 9, 31, 13.5), makeCuboidShape(9.475, 0.975, 13, 15.025, 31.025, 13.025),
							makeCuboidShape(0.975, 0.975, 13, 9.025, 31.025, 13.025), makeCuboidShape(10, 6, 13.5, 10.25, 23, 13.75), makeCuboidShape(10, 6, 13.75, 10.5, 23, 14), makeCuboidShape(8.25, 6, 13.5, 8.5, 23, 13.75),
							makeCuboidShape(8, 6, 13.75, 8.5, 23, 14), makeCuboidShape(1, 1, 0.5, 15, 31, 1), makeCuboidShape(0.25, 0.15, 0.975, 2.75, 0.825, 1));
			}
		});
	}

	private ImmutableMap<BlockState, VoxelShape> getShapeForEachState(Function<BlockState, VoxelShape> func) {
		return stateContainer.getValidStates().stream().collect(ImmutableMap.toImmutableMap(Function.identity(), func));
	}

	@Override
	public VoxelShape getShape(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext context) {
		return shapes.get(state);
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public BlockRenderLayer getRenderLayer() {
		return BlockRenderLayer.CUTOUT;
	}

	@Override
	public boolean isNormalCube(BlockState state, IBlockReader worldIn, BlockPos pos) {
		return false;
	}

	@Override
	public VoxelShape getRaytraceShape(BlockState state, IBlockReader world, BlockPos pos) {
		return VoxelShapes.empty();
	}

	@Override
	protected void fillStateContainer(StateContainer.Builder<Block, BlockState> builder) {
		super.fillStateContainer(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockItemUseContext context) {
		return super.getStateForPlacement(context).with(FACING, context.getPlacementHorizontalFacing().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.with(FACING, rot.rotate(state.get(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.toRotation(state.get(FACING)));
	}
}