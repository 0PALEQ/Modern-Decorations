package com.cookiecraftmods.mdm.block;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.IBlockReader;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Rotation;
import net.minecraft.util.Mirror;
import net.minecraft.util.Direction;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.state.StateContainer;
import net.minecraft.state.DirectionProperty;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.block.material.Material;
import net.minecraft.block.SoundType;
import net.minecraft.block.HorizontalBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Block;

import com.google.common.collect.ImmutableMap;

public class RainShowerBlock extends Block {
	public static final DirectionProperty FACING = HorizontalBlock.HORIZONTAL_FACING;
	private final ImmutableMap<BlockState, VoxelShape> shapes = this.makeShapes();

	public RainShowerBlock() {
		super(Block.Properties.create(Material.REDSTONE_LIGHT).sound(SoundType.METAL).hardnessAndResistance(1f, 10f));
		this.setDefaultState(this.stateContainer.getBaseState().with(FACING, Direction.NORTH));
	}

	@Override
	public boolean isSolid(BlockState state) {
		return false;
	}

	private ImmutableMap<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			switch (state.get(FACING)) {
				case NORTH :
					return VoxelShapes.or(makeCuboidShape(7.25, 12.25, 8, 8.75, 13.75, 16), makeCuboidShape(7.25, 10.75, 8, 8.75, 12.25, 9), makeCuboidShape(6.25, 9.75, 6.75, 9.75, 10.75, 10.25), makeCuboidShape(6.75, 9.5, 7.25, 9.25, 9.75, 9.75),
							makeCuboidShape(4, 3, 14, 6, 5, 16), makeCuboidShape(10, 3, 14, 12, 5, 16));
				case EAST :
					return VoxelShapes.or(makeCuboidShape(0, 12.25, 7.25, 8, 13.75, 8.75), makeCuboidShape(7, 10.75, 7.25, 8, 12.25, 8.75), makeCuboidShape(5.75, 9.75, 6.25, 9.25, 10.75, 9.75), makeCuboidShape(6.25, 9.5, 6.75, 8.75, 9.75, 9.25),
							makeCuboidShape(0, 3, 4, 2, 5, 6), makeCuboidShape(0, 3, 10, 2, 5, 12));
				case WEST :
					return VoxelShapes.or(makeCuboidShape(8, 12.25, 7.25, 16, 13.75, 8.75), makeCuboidShape(8, 10.75, 7.25, 9, 12.25, 8.75), makeCuboidShape(6.75, 9.75, 6.25, 10.25, 10.75, 9.75), makeCuboidShape(7.25, 9.5, 6.75, 9.75, 9.75, 9.25),
							makeCuboidShape(14, 3, 10, 16, 5, 12), makeCuboidShape(14, 3, 4, 16, 5, 6));
				default :
					return VoxelShapes.or(makeCuboidShape(7.25, 12.25, 0, 8.75, 13.75, 8), makeCuboidShape(7.25, 10.75, 7, 8.75, 12.25, 8), makeCuboidShape(6.25, 9.75, 5.75, 9.75, 10.75, 9.25), makeCuboidShape(6.75, 9.5, 6.25, 9.25, 9.75, 8.75),
							makeCuboidShape(10, 3, 0, 12, 5, 2), makeCuboidShape(4, 3, 0, 6, 5, 2));
			}
		});
	}

	private ImmutableMap<BlockState, VoxelShape> getShapeForEachState(Function<BlockState, VoxelShape> func) {
		return stateContainer.getValidStates().stream().collect(ImmutableMap.toImmutableMap(Function.identity(), func));
	}

	@Override
	public VoxelShape getShape(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext context) {
		return shapes.get(state);
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public BlockRenderLayer getRenderLayer() {
		return BlockRenderLayer.CUTOUT;
	}

	@Override
	public boolean isNormalCube(BlockState state, IBlockReader worldIn, BlockPos pos) {
		return false;
	}

	@Override
	public VoxelShape getRaytraceShape(BlockState state, IBlockReader world, BlockPos pos) {
		return VoxelShapes.empty();
	}

	@Override
	protected void fillStateContainer(StateContainer.Builder<Block, BlockState> builder) {
		super.fillStateContainer(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockItemUseContext context) {
		return super.getStateForPlacement(context).with(FACING, context.getPlacementHorizontalFacing().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.with(FACING, rot.rotate(state.get(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.toRotation(state.get(FACING)));
	}
}