package com.cookiecraftmods.mdm.block;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.IBlockReader;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Rotation;
import net.minecraft.util.Mirror;
import net.minecraft.util.Direction;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.state.StateContainer;
import net.minecraft.state.DirectionProperty;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.block.material.Material;
import net.minecraft.block.SoundType;
import net.minecraft.block.HorizontalBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Block;

import com.google.common.collect.ImmutableMap;

public class ToiletBlock extends Block {
	public static final DirectionProperty FACING = HorizontalBlock.HORIZONTAL_FACING;
	private final ImmutableMap<BlockState, VoxelShape> shapes = this.makeShapes();

	public ToiletBlock() {
		super(Block.Properties.create(Material.REDSTONE_LIGHT).sound(SoundType.GROUND).hardnessAndResistance(1f, 10f));
		this.setDefaultState(this.stateContainer.getBaseState().with(FACING, Direction.NORTH));
	}

	@Override
	public boolean isSolid(BlockState state) {
		return false;
	}

	private ImmutableMap<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			switch (state.get(FACING)) {
				case NORTH :
					return VoxelShapes.or(makeCuboidShape(6, 3, 14, 10, 5, 16), makeCuboidShape(8, 22, 15.95, 10, 24, 16), makeCuboidShape(5, 21, 15.975, 11, 25, 16), makeCuboidShape(6, 22, 15.95, 7, 24, 16), makeCuboidShape(5, 5, 7, 11, 6, 16),
							makeCuboidShape(3, 6, 3, 13, 9, 16), makeCuboidShape(3, 9.25, 3, 13, 10.25, 15), makeCuboidShape(4, 9, 4, 12, 9.25, 14.5));
				case EAST :
					return VoxelShapes.or(makeCuboidShape(0, 3, 6, 2, 5, 10), makeCuboidShape(0, 22, 8, 0.05, 24, 10), makeCuboidShape(0, 21, 5, 0.025, 25, 11), makeCuboidShape(0, 22, 6, 0.05, 24, 7), makeCuboidShape(0, 5, 5, 9, 6, 11),
							makeCuboidShape(0, 6, 3, 13, 9, 13), makeCuboidShape(1, 9.25, 3, 13, 10.25, 13), makeCuboidShape(1.5, 9, 4, 12, 9.25, 12));
				case WEST :
					return VoxelShapes.or(makeCuboidShape(14, 3, 6, 16, 5, 10), makeCuboidShape(15.95, 22, 6, 16, 24, 8), makeCuboidShape(15.975, 21, 5, 16, 25, 11), makeCuboidShape(15.95, 22, 9, 16, 24, 10), makeCuboidShape(7, 5, 5, 16, 6, 11),
							makeCuboidShape(3, 6, 3, 16, 9, 13), makeCuboidShape(3, 9.25, 3, 15, 10.25, 13), makeCuboidShape(4, 9, 4, 14.5, 9.25, 12));
				default :
					return VoxelShapes.or(makeCuboidShape(6, 3, 0, 10, 5, 2), makeCuboidShape(6, 22, 0, 8, 24, 0.05), makeCuboidShape(5, 21, 0, 11, 25, 0.025), makeCuboidShape(9, 22, 0, 10, 24, 0.05), makeCuboidShape(5, 5, 0, 11, 6, 9),
							makeCuboidShape(3, 6, 0, 13, 9, 13), makeCuboidShape(3, 9.25, 1, 13, 10.25, 13), makeCuboidShape(4, 9, 1.5, 12, 9.25, 12));
			}
		});
	}

	private ImmutableMap<BlockState, VoxelShape> getShapeForEachState(Function<BlockState, VoxelShape> func) {
		return stateContainer.getValidStates().stream().collect(ImmutableMap.toImmutableMap(Function.identity(), func));
	}

	@Override
	public VoxelShape getShape(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext context) {
		return shapes.get(state);
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public BlockRenderLayer getRenderLayer() {
		return BlockRenderLayer.CUTOUT;
	}

	@Override
	public boolean isNormalCube(BlockState state, IBlockReader worldIn, BlockPos pos) {
		return false;
	}

	@Override
	public VoxelShape getRaytraceShape(BlockState state, IBlockReader world, BlockPos pos) {
		return VoxelShapes.empty();
	}

	@Override
	protected void fillStateContainer(StateContainer.Builder<Block, BlockState> builder) {
		super.fillStateContainer(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockItemUseContext context) {
		return super.getStateForPlacement(context).with(FACING, context.getPlacementHorizontalFacing().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.with(FACING, rot.rotate(state.get(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.toRotation(state.get(FACING)));
	}
}