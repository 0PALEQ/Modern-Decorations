package com.cookiecraftmods.mdm.item;

import net.minecraft.item.Item;

import com.cookiecraftmods.mdm.init.MdmModTabs;

public class LightOakFurniturePartsItem extends Item {
	public LightOakFurniturePartsItem() {
		super(new Item.Properties().group(MdmModTabs.TAB_OFFICE));
	}
}