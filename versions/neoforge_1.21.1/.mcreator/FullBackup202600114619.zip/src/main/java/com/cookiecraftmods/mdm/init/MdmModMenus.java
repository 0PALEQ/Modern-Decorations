/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package com.cookiecraftmods.mdm.init;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.network.PacketDistributor;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.common.extensions.IForgeContainerType;

import net.minecraft.inventory.container.Slot;
import net.minecraft.inventory.container.ContainerType;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.Minecraft;

import com.cookiecraftmods.mdm.world.inventory.StorageMenu;
import com.cookiecraftmods.mdm.world.inventory.OvenGuiMenu;
import com.cookiecraftmods.mdm.world.inventory.FridgeGuiMenu;
import com.cookiecraftmods.mdm.world.inventory.FreezerguiMenu;
import com.cookiecraftmods.mdm.network.MenuStateUpdateMessage;
import com.cookiecraftmods.mdm.MdmMod;

public class MdmModMenus {
	public static final DeferredRegister<ContainerType<?>> REGISTRY = new DeferredRegister<>(ForgeRegistries.CONTAINERS, MdmMod.MODID);
	public static final RegistryObject<ContainerType<StorageMenu>> STORAGE = REGISTRY.register("storage", () -> IForgeContainerType.create(StorageMenu::new));
	public static final RegistryObject<ContainerType<FreezerguiMenu>> FREEZERGUI = REGISTRY.register("freezergui", () -> IForgeContainerType.create(FreezerguiMenu::new));
	public static final RegistryObject<ContainerType<FridgeGuiMenu>> FRIDGE_GUI = REGISTRY.register("fridge_gui", () -> IForgeContainerType.create(FridgeGuiMenu::new));
	public static final RegistryObject<ContainerType<OvenGuiMenu>> OVEN_GUI = REGISTRY.register("oven_gui", () -> IForgeContainerType.create(OvenGuiMenu::new));

	public interface MenuAccessor {
		Map<String, Object> getMenuState();

		Map<Integer, Slot> getSlots();

		default void sendMenuStateUpdate(PlayerEntity player, int elementType, String name, Object elementState, boolean needClientUpdate) {
			getMenuState().put(elementType + ":" + name, elementState);
			if (player instanceof ServerPlayerEntity) {
				MdmMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayerEntity) player), new MenuStateUpdateMessage(elementType, name, elementState));
			} else if (player.world.isRemote) {
				if (Minecraft.getInstance().currentScreen instanceof MdmModScreens.ScreenAccessor && needClientUpdate)
					((MdmModScreens.ScreenAccessor) Minecraft.getInstance().currentScreen).updateMenuState(elementType, name, elementState);
				MdmMod.PACKET_HANDLER.sendToServer(new MenuStateUpdateMessage(elementType, name, elementState));
			}
		}

		default <T> T getMenuState(int elementType, String name, T defaultValue) {
			try {
				return (T) getMenuState().getOrDefault(elementType + ":" + name, defaultValue);
			} catch (ClassCastException e) {
				return defaultValue;
			}
		}
	}
}