package com.cookiecraftmods.mdm.block;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.IBlockReader;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Rotation;
import net.minecraft.util.Mirror;
import net.minecraft.util.Direction;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.state.StateContainer;
import net.minecraft.state.DirectionProperty;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.block.material.Material;
import net.minecraft.block.SoundType;
import net.minecraft.block.HorizontalBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Block;

import com.google.common.collect.ImmutableMap;

public class SoapBarBlock extends Block {
	public static final DirectionProperty FACING = HorizontalBlock.HORIZONTAL_FACING;
	private final ImmutableMap<BlockState, VoxelShape> shapes = this.makeShapes();

	public SoapBarBlock() {
		super(Block.Properties.create(Material.REDSTONE_LIGHT).sound(SoundType.GROUND).hardnessAndResistance(1f, 10f));
		this.setDefaultState(this.stateContainer.getBaseState().with(FACING, Direction.NORTH));
	}

	@Override
	public boolean isSolid(BlockState state) {
		return false;
	}

	private ImmutableMap<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			switch (state.get(FACING)) {
				case NORTH :
					return VoxelShapes.or(makeCuboidShape(5, 0, 11, 11, 0.25, 15), makeCuboidShape(5, 0.25, 14.5, 11, 0.5, 15), makeCuboidShape(5, 0.25, 11, 11, 0.5, 11.5), makeCuboidShape(5, 0.25, 11.5, 5.5, 0.5, 14.5),
							makeCuboidShape(10.5, 0.25, 11.5, 11, 0.5, 14.5), makeCuboidShape(6, 0.25, 12, 10, 1, 14));
				case EAST :
					return VoxelShapes.or(makeCuboidShape(1, 0, 5, 5, 0.25, 11), makeCuboidShape(1, 0.25, 5, 1.5, 0.5, 11), makeCuboidShape(4.5, 0.25, 5, 5, 0.5, 11), makeCuboidShape(1.5, 0.25, 5, 4.5, 0.5, 5.5),
							makeCuboidShape(1.5, 0.25, 10.5, 4.5, 0.5, 11), makeCuboidShape(2, 0.25, 6, 4, 1, 10));
				case WEST :
					return VoxelShapes.or(makeCuboidShape(11, 0, 5, 15, 0.25, 11), makeCuboidShape(14.5, 0.25, 5, 15, 0.5, 11), makeCuboidShape(11, 0.25, 5, 11.5, 0.5, 11), makeCuboidShape(11.5, 0.25, 10.5, 14.5, 0.5, 11),
							makeCuboidShape(11.5, 0.25, 5, 14.5, 0.5, 5.5), makeCuboidShape(12, 0.25, 6, 14, 1, 10));
				default :
					return VoxelShapes.or(makeCuboidShape(5, 0, 1, 11, 0.25, 5), makeCuboidShape(5, 0.25, 1, 11, 0.5, 1.5), makeCuboidShape(5, 0.25, 4.5, 11, 0.5, 5), makeCuboidShape(10.5, 0.25, 1.5, 11, 0.5, 4.5),
							makeCuboidShape(5, 0.25, 1.5, 5.5, 0.5, 4.5), makeCuboidShape(6, 0.25, 2, 10, 1, 4));
			}
		});
	}

	private ImmutableMap<BlockState, VoxelShape> getShapeForEachState(Function<BlockState, VoxelShape> func) {
		return stateContainer.getValidStates().stream().collect(ImmutableMap.toImmutableMap(Function.identity(), func));
	}

	@Override
	public VoxelShape getShape(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext context) {
		return shapes.get(state);
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public BlockRenderLayer getRenderLayer() {
		return BlockRenderLayer.CUTOUT;
	}

	@Override
	public boolean isNormalCube(BlockState state, IBlockReader worldIn, BlockPos pos) {
		return false;
	}

	@Override
	public VoxelShape getRaytraceShape(BlockState state, IBlockReader world, BlockPos pos) {
		return VoxelShapes.empty();
	}

	@Override
	protected void fillStateContainer(StateContainer.Builder<Block, BlockState> builder) {
		super.fillStateContainer(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockItemUseContext context) {
		return super.getStateForPlacement(context).with(FACING, context.getPlacementHorizontalFacing().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.with(FACING, rot.rotate(state.get(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.toRotation(state.get(FACING)));
	}
}