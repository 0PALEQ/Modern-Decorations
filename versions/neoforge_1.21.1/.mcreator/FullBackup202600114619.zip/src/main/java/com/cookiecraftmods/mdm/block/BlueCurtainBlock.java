package com.cookiecraftmods.mdm.block;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.IBlockReader;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Rotation;
import net.minecraft.util.Mirror;
import net.minecraft.util.Direction;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.state.properties.AttachFace;
import net.minecraft.state.StateContainer;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.block.material.Material;
import net.minecraft.block.SoundType;
import net.minecraft.block.HorizontalFaceBlock;
import net.minecraft.block.HorizontalBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Block;

import com.google.common.collect.ImmutableMap;

public class BlueCurtainBlock extends Block {
	public static final DirectionProperty FACING = HorizontalBlock.HORIZONTAL_FACING;
	public static final EnumProperty<AttachFace> FACE = HorizontalFaceBlock.FACE;
	private final ImmutableMap<BlockState, VoxelShape> shapes = this.makeShapes();

	public BlueCurtainBlock() {
		super(Block.Properties.create(Material.REDSTONE_LIGHT).sound(SoundType.CLOTH).hardnessAndResistance(1f, 10f));
		this.setDefaultState(this.stateContainer.getBaseState().with(FACING, Direction.NORTH).with(FACE, AttachFace.WALL));
	}

	@Override
	public boolean isSolid(BlockState state) {
		return false;
	}

	private ImmutableMap<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			switch (state.get(FACING)) {
				case NORTH :
					switch (state.get(FACE)) {
						case FLOOR :
							return makeCuboidShape(-4, -16, 14, 20, 32, 16);
						case WALL :
							return makeCuboidShape(-4, 14, -16, 20, 16, 32);
						default :
							return makeCuboidShape(-4, -16, 14, 20, 32, 16);
					}
				case EAST :
					switch (state.get(FACE)) {
						case FLOOR :
							return makeCuboidShape(0, -16, -4, 2, 32, 20);
						case WALL :
							return makeCuboidShape(-16, 14, -4, 32, 16, 20);
						default :
							return makeCuboidShape(0, -16, -4, 2, 32, 20);
					}
				case WEST :
					switch (state.get(FACE)) {
						case FLOOR :
							return makeCuboidShape(14, -16, -4, 16, 32, 20);
						case WALL :
							return makeCuboidShape(-16, 14, -4, 32, 16, 20);
						default :
							return makeCuboidShape(14, -16, -4, 16, 32, 20);
					}
				default :
					switch (state.get(FACE)) {
						case FLOOR :
							return makeCuboidShape(-4, -16, 0, 20, 32, 2);
						case WALL :
							return makeCuboidShape(-4, 14, -16, 20, 16, 32);
						default :
							return makeCuboidShape(-4, -16, 0, 20, 32, 2);
					}
			}
		});
	}

	private ImmutableMap<BlockState, VoxelShape> getShapeForEachState(Function<BlockState, VoxelShape> func) {
		return stateContainer.getValidStates().stream().collect(ImmutableMap.toImmutableMap(Function.identity(), func));
	}

	@Override
	public VoxelShape getShape(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext context) {
		return shapes.get(state);
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public BlockRenderLayer getRenderLayer() {
		return BlockRenderLayer.TRANSLUCENT;
	}

	@Override
	public boolean isNormalCube(BlockState state, IBlockReader worldIn, BlockPos pos) {
		return false;
	}

	@Override
	public VoxelShape getRaytraceShape(BlockState state, IBlockReader world, BlockPos pos) {
		return VoxelShapes.empty();
	}

	@Override
	protected void fillStateContainer(StateContainer.Builder<Block, BlockState> builder) {
		super.fillStateContainer(builder);
		builder.add(FACING, FACE);
	}

	@Override
	public BlockState getStateForPlacement(BlockItemUseContext context) {
		return super.getStateForPlacement(context).with(FACE, faceForDirection(context.getNearestLookingDirection())).with(FACING, context.getPlacementHorizontalFacing().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.with(FACING, rot.rotate(state.get(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.toRotation(state.get(FACING)));
	}

	private AttachFace faceForDirection(Direction direction) {
		if (direction.getAxis() == Direction.Axis.Y)
			return direction == Direction.UP ? AttachFace.CEILING : AttachFace.FLOOR;
		else
			return AttachFace.WALL;
	}
}