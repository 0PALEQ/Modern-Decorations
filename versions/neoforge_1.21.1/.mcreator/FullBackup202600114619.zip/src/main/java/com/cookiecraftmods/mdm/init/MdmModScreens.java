/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package com.cookiecraftmods.mdm.init;

import org.lwjgl.glfw.GLFW;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.util.text.TextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.gui.widget.AbstractSlider;
import net.minecraft.client.gui.ScreenManager;

import java.text.DecimalFormat;

import com.cookiecraftmods.mdm.client.gui.StorageScreen;
import com.cookiecraftmods.mdm.client.gui.OvenGuiScreen;
import com.cookiecraftmods.mdm.client.gui.FridgeGuiScreen;
import com.cookiecraftmods.mdm.client.gui.FreezerguiScreen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MdmModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		ScreenManager.registerFactory(MdmModMenus.STORAGE.get(), StorageScreen::new);
		ScreenManager.registerFactory(MdmModMenus.FREEZERGUI.get(), FreezerguiScreen::new);
		ScreenManager.registerFactory(MdmModMenus.FRIDGE_GUI.get(), FridgeGuiScreen::new);
		ScreenManager.registerFactory(MdmModMenus.OVEN_GUI.get(), OvenGuiScreen::new);
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}

	public static class ForgeSlider extends AbstractSlider {
		protected TextComponent prefix;
		protected TextComponent suffix;
		protected double minValue;
		protected double maxValue;
		protected double stepSize;
		protected boolean drawString;
		private final DecimalFormat format;

		public ForgeSlider(int x, int y, int width, int height, TextComponent prefix, TextComponent suffix, double minValue, double maxValue, double currentValue, double stepSize, int precision, boolean drawString) {
			super(x, y, width, height, 0D);
			this.prefix = prefix;
			this.suffix = suffix;
			this.minValue = minValue;
			this.maxValue = maxValue;
			this.stepSize = Math.abs(stepSize);
			this.value = this.snapToNearest((currentValue - minValue) / (maxValue - minValue));
			this.drawString = drawString;
			if (stepSize == 0D) {
				precision = Math.min(precision, 4);
				StringBuilder builder = new StringBuilder("0");
				if (precision > 0)
					builder.append('.');
				while (precision-- > 0)
					builder.append('0');
				this.format = new DecimalFormat(builder.toString());
			} else if (MathHelper.epsilonEquals(this.stepSize, Math.floor(this.stepSize))) {
				this.format = new DecimalFormat("0");
			} else {
				this.format = new DecimalFormat(Double.toString(this.stepSize).replaceAll("\\d", "0"));
			}
			this.updateMessage();
		}

		public ForgeSlider(int x, int y, int width, int height, TextComponent prefix, TextComponent suffix, double minValue, double maxValue, double currentValue, boolean drawString) {
			this(x, y, width, height, prefix, suffix, minValue, maxValue, currentValue, 1D, 0, drawString);
		}

		public double getValue() {
			return this.value * (maxValue - minValue) + minValue;
		}

		public long getValueLong() {
			return Math.round(this.getValue());
		}

		public int getValueInt() {
			return (int) this.getValueLong();
		}

		public void setValue(double value) {
			this.value = this.snapToNearest((value - this.minValue) / (this.maxValue - this.minValue));
			this.updateMessage();
		}

		public String getValueString() {
			return this.format.format(this.getValue());
		}

		@Override
		public void onClick(double mouseX, double mouseY) {
			this.setValueFromMouse(mouseX);
		}

		@Override
		protected void onDrag(double mouseX, double mouseY, double dragX, double dragY) {
			super.onDrag(mouseX, mouseY, dragX, dragY);
			this.setValueFromMouse(mouseX);
		}

		@Override
		public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
			boolean flag = keyCode == GLFW.GLFW_KEY_LEFT;
			if (flag || keyCode == GLFW.GLFW_KEY_RIGHT) {
				if (this.minValue > this.maxValue)
					flag = !flag;
				float f = flag ? -1F : 1F;
				if (stepSize <= 0D)
					this.setSliderValue(this.value + (f / (this.width - 8)));
				else
					this.setValue(this.getValue() + f * this.stepSize);
			}
			return false;
		}

		private void setValueFromMouse(double mouseX) {
			this.setSliderValue((mouseX - (this.x + 4)) / (this.width - 8));
		}

		private void setSliderValue(double value) {
			double oldValue = this.value;
			this.value = this.snapToNearest(value);
			if (!MathHelper.epsilonEquals(oldValue, this.value))
				this.applyValue();
			this.updateMessage();
		}

		private double snapToNearest(double value) {
			if (stepSize <= 0D)
				return MathHelper.clamp(value, 0D, 1D);
			value = MathHelper.lerp(MathHelper.clamp(value, 0D, 1D), this.minValue, this.maxValue);
			value = (stepSize * Math.round(value / stepSize));
			if (this.minValue > this.maxValue) {
				value = MathHelper.clamp(value, this.maxValue, this.minValue);
			} else {
				value = MathHelper.clamp(value, this.minValue, this.maxValue);
			}
			return MathHelper.lerp(MathHelper.pct(value, this.minValue, this.maxValue), 0D, 1D);
		}

		@Override
		protected void updateMessage() {
			if (this.drawString) {
				this.setMessage(new StringTextComponent("").appendSibling(prefix).appendText(this.getValueString()).appendSibling(suffix).getString());
			} else {
				this.setMessage("");
			}
		}

		@Override
		protected void applyValue() {
		}
	}
}