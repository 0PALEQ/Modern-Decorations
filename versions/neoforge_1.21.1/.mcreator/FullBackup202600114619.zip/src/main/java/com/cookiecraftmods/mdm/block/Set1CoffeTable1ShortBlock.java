package com.cookiecraftmods.mdm.block;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.IBlockReader;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Rotation;
import net.minecraft.util.Mirror;
import net.minecraft.util.Direction;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.state.StateContainer;
import net.minecraft.state.DirectionProperty;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.block.material.Material;
import net.minecraft.block.SoundType;
import net.minecraft.block.HorizontalBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Block;

import com.google.common.collect.ImmutableMap;

public class Set1CoffeTable1ShortBlock extends Block {
	public static final DirectionProperty FACING = HorizontalBlock.HORIZONTAL_FACING;
	private final ImmutableMap<BlockState, VoxelShape> shapes = this.makeShapes();

	public Set1CoffeTable1ShortBlock() {
		super(Block.Properties.create(Material.REDSTONE_LIGHT).sound(SoundType.WOOD).hardnessAndResistance(1f, 10f));
		this.setDefaultState(this.stateContainer.getBaseState().with(FACING, Direction.NORTH));
	}

	@Override
	public boolean isSolid(BlockState state) {
		return false;
	}

	private ImmutableMap<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			switch (state.get(FACING)) {
				case NORTH :
					return VoxelShapes.or(makeCuboidShape(1, 5, 1, 16, 8, 15), makeCuboidShape(5.5, 0, 0.25, 7.5, 1, 15.75), makeCuboidShape(5.5, 4.5, 1, 7.5, 5, 15), makeCuboidShape(5.5, 1, 15, 7.5, 7, 15.75),
							makeCuboidShape(5.5, 1, 0.25, 7.5, 7, 1));
				case EAST :
					return VoxelShapes.or(makeCuboidShape(1, 5, 1, 15, 8, 16), makeCuboidShape(0.25, 0, 5.5, 15.75, 1, 7.5), makeCuboidShape(1, 4.5, 5.5, 15, 5, 7.5), makeCuboidShape(0.25, 1, 5.5, 1, 7, 7.5),
							makeCuboidShape(15, 1, 5.5, 15.75, 7, 7.5));
				case WEST :
					return VoxelShapes.or(makeCuboidShape(1, 5, 0, 15, 8, 15), makeCuboidShape(0.25, 0, 8.5, 15.75, 1, 10.5), makeCuboidShape(1, 4.5, 8.5, 15, 5, 10.5), makeCuboidShape(15, 1, 8.5, 15.75, 7, 10.5),
							makeCuboidShape(0.25, 1, 8.5, 1, 7, 10.5));
				default :
					return VoxelShapes.or(makeCuboidShape(0, 5, 1, 15, 8, 15), makeCuboidShape(8.5, 0, 0.25, 10.5, 1, 15.75), makeCuboidShape(8.5, 4.5, 1, 10.5, 5, 15), makeCuboidShape(8.5, 1, 0.25, 10.5, 7, 1),
							makeCuboidShape(8.5, 1, 15, 10.5, 7, 15.75));
			}
		});
	}

	private ImmutableMap<BlockState, VoxelShape> getShapeForEachState(Function<BlockState, VoxelShape> func) {
		return stateContainer.getValidStates().stream().collect(ImmutableMap.toImmutableMap(Function.identity(), func));
	}

	@Override
	public VoxelShape getShape(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext context) {
		return shapes.get(state);
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public BlockRenderLayer getRenderLayer() {
		return BlockRenderLayer.CUTOUT;
	}

	@Override
	public boolean isNormalCube(BlockState state, IBlockReader worldIn, BlockPos pos) {
		return false;
	}

	@Override
	public VoxelShape getRaytraceShape(BlockState state, IBlockReader world, BlockPos pos) {
		return VoxelShapes.empty();
	}

	@Override
	protected void fillStateContainer(StateContainer.Builder<Block, BlockState> builder) {
		super.fillStateContainer(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockItemUseContext context) {
		return super.getStateForPlacement(context).with(FACING, context.getPlacementHorizontalFacing().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.with(FACING, rot.rotate(state.get(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.toRotation(state.get(FACING)));
	}
}