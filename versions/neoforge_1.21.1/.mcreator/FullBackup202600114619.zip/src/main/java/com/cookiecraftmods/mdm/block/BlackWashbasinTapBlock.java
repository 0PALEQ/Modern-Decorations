package com.cookiecraftmods.mdm.block;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.IBlockReader;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Rotation;
import net.minecraft.util.Mirror;
import net.minecraft.util.Direction;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.state.StateContainer;
import net.minecraft.state.DirectionProperty;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.block.material.Material;
import net.minecraft.block.SoundType;
import net.minecraft.block.HorizontalBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Block;

import com.google.common.collect.ImmutableMap;

public class BlackWashbasinTapBlock extends Block {
	public static final DirectionProperty FACING = HorizontalBlock.HORIZONTAL_FACING;
	private final ImmutableMap<BlockState, VoxelShape> shapes = this.makeShapes();

	public BlackWashbasinTapBlock() {
		super(Block.Properties.create(Material.REDSTONE_LIGHT).sound(SoundType.METAL).hardnessAndResistance(1f, 10f));
		this.setDefaultState(this.stateContainer.getBaseState().with(FACING, Direction.NORTH));
	}

	@Override
	public boolean isSolid(BlockState state) {
		return false;
	}

	private ImmutableMap<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			switch (state.get(FACING)) {
				case NORTH :
					return VoxelShapes.or(makeCuboidShape(7.5, 2, 12, 8.5, 2.5, 16), makeCuboidShape(6, 0, 14.5, 7, 0.75, 15.5), makeCuboidShape(9, 0, 14.5, 10, 0.75, 15.5), makeCuboidShape(7.75, 1.75, 12.25, 8.25, 2, 12.75));
				case EAST :
					return VoxelShapes.or(makeCuboidShape(0, 2, 7.5, 4, 2.5, 8.5), makeCuboidShape(0.5, 0, 6, 1.5, 0.75, 7), makeCuboidShape(0.5, 0, 9, 1.5, 0.75, 10), makeCuboidShape(3.25, 1.75, 7.75, 3.75, 2, 8.25));
				case WEST :
					return VoxelShapes.or(makeCuboidShape(12, 2, 7.5, 16, 2.5, 8.5), makeCuboidShape(14.5, 0, 9, 15.5, 0.75, 10), makeCuboidShape(14.5, 0, 6, 15.5, 0.75, 7), makeCuboidShape(12.25, 1.75, 7.75, 12.75, 2, 8.25));
				default :
					return VoxelShapes.or(makeCuboidShape(7.5, 2, 0, 8.5, 2.5, 4), makeCuboidShape(9, 0, 0.5, 10, 0.75, 1.5), makeCuboidShape(6, 0, 0.5, 7, 0.75, 1.5), makeCuboidShape(7.75, 1.75, 3.25, 8.25, 2, 3.75));
			}
		});
	}

	private ImmutableMap<BlockState, VoxelShape> getShapeForEachState(Function<BlockState, VoxelShape> func) {
		return stateContainer.getValidStates().stream().collect(ImmutableMap.toImmutableMap(Function.identity(), func));
	}

	@Override
	public VoxelShape getShape(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext context) {
		return shapes.get(state);
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public BlockRenderLayer getRenderLayer() {
		return BlockRenderLayer.CUTOUT;
	}

	@Override
	public boolean isNormalCube(BlockState state, IBlockReader worldIn, BlockPos pos) {
		return false;
	}

	@Override
	public VoxelShape getRaytraceShape(BlockState state, IBlockReader world, BlockPos pos) {
		return VoxelShapes.empty();
	}

	@Override
	protected void fillStateContainer(StateContainer.Builder<Block, BlockState> builder) {
		super.fillStateContainer(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockItemUseContext context) {
		return super.getStateForPlacement(context).with(FACING, context.getPlacementHorizontalFacing().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.with(FACING, rot.rotate(state.get(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.toRotation(state.get(FACING)));
	}
}