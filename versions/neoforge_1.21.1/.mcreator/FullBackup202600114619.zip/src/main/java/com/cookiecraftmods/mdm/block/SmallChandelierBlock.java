package com.cookiecraftmods.mdm.block;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.IBlockReader;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Rotation;
import net.minecraft.util.Mirror;
import net.minecraft.util.Direction;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.state.StateContainer;
import net.minecraft.state.DirectionProperty;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.block.material.Material;
import net.minecraft.block.SoundType;
import net.minecraft.block.HorizontalBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Block;

import com.google.common.collect.ImmutableMap;

public class SmallChandelierBlock extends Block {
	public static final DirectionProperty FACING = HorizontalBlock.HORIZONTAL_FACING;
	private final ImmutableMap<BlockState, VoxelShape> shapes = this.makeShapes();

	public SmallChandelierBlock() {
		super(Block.Properties.create(Material.REDSTONE_LIGHT).sound(SoundType.GLASS).hardnessAndResistance(1f, 10f).lightValue(15));
		this.setDefaultState(this.stateContainer.getBaseState().with(FACING, Direction.NORTH));
	}

	@Override
	public boolean isSolid(BlockState state) {
		return false;
	}

	private ImmutableMap<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			switch (state.get(FACING)) {
				case NORTH :
					return VoxelShapes.or(makeCuboidShape(0, 14, 7, 16, 16, 9), makeCuboidShape(13.7, 10, 7.5, 14.7, 14, 8.5), makeCuboidShape(1.45, 10, 7.5, 2.45, 14, 8.5), makeCuboidShape(5.45, 10, 7.5, 6.45, 14, 8.5),
							makeCuboidShape(9.7, 10, 7.5, 10.7, 14, 8.5), makeCuboidShape(13.2, 8, 7, 15.2, 10, 9), makeCuboidShape(0.95, 8, 7, 2.95, 10, 9), makeCuboidShape(4.95, 8, 7, 6.95, 10, 9), makeCuboidShape(9.2, 8, 7, 11.2, 10, 9));
				case EAST :
					return VoxelShapes.or(makeCuboidShape(7, 14, 0, 9, 16, 16), makeCuboidShape(7.5, 10, 13.7, 8.5, 14, 14.7), makeCuboidShape(7.5, 10, 1.45, 8.5, 14, 2.45), makeCuboidShape(7.5, 10, 5.45, 8.5, 14, 6.45),
							makeCuboidShape(7.5, 10, 9.7, 8.5, 14, 10.7), makeCuboidShape(7, 8, 13.2, 9, 10, 15.2), makeCuboidShape(7, 8, 0.95, 9, 10, 2.95), makeCuboidShape(7, 8, 4.95, 9, 10, 6.95), makeCuboidShape(7, 8, 9.2, 9, 10, 11.2));
				case WEST :
					return VoxelShapes.or(makeCuboidShape(7, 14, 0, 9, 16, 16), makeCuboidShape(7.5, 10, 1.3, 8.5, 14, 2.3), makeCuboidShape(7.5, 10, 13.55, 8.5, 14, 14.55), makeCuboidShape(7.5, 10, 9.55, 8.5, 14, 10.55),
							makeCuboidShape(7.5, 10, 5.3, 8.5, 14, 6.3), makeCuboidShape(7, 8, 0.8, 9, 10, 2.8), makeCuboidShape(7, 8, 13.05, 9, 10, 15.05), makeCuboidShape(7, 8, 9.05, 9, 10, 11.05), makeCuboidShape(7, 8, 4.8, 9, 10, 6.8));
				default :
					return VoxelShapes.or(makeCuboidShape(0, 14, 7, 16, 16, 9), makeCuboidShape(1.3, 10, 7.5, 2.3, 14, 8.5), makeCuboidShape(13.55, 10, 7.5, 14.55, 14, 8.5), makeCuboidShape(9.55, 10, 7.5, 10.55, 14, 8.5),
							makeCuboidShape(5.3, 10, 7.5, 6.3, 14, 8.5), makeCuboidShape(0.8, 8, 7, 2.8, 10, 9), makeCuboidShape(13.05, 8, 7, 15.05, 10, 9), makeCuboidShape(9.05, 8, 7, 11.05, 10, 9), makeCuboidShape(4.8, 8, 7, 6.8, 10, 9));
			}
		});
	}

	private ImmutableMap<BlockState, VoxelShape> getShapeForEachState(Function<BlockState, VoxelShape> func) {
		return stateContainer.getValidStates().stream().collect(ImmutableMap.toImmutableMap(Function.identity(), func));
	}

	@Override
	public VoxelShape getShape(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext context) {
		return shapes.get(state);
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public BlockRenderLayer getRenderLayer() {
		return BlockRenderLayer.CUTOUT;
	}

	@Override
	public boolean isNormalCube(BlockState state, IBlockReader worldIn, BlockPos pos) {
		return false;
	}

	@Override
	public VoxelShape getRaytraceShape(BlockState state, IBlockReader world, BlockPos pos) {
		return VoxelShapes.empty();
	}

	@Override
	protected void fillStateContainer(StateContainer.Builder<Block, BlockState> builder) {
		super.fillStateContainer(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockItemUseContext context) {
		return super.getStateForPlacement(context).with(FACING, context.getPlacementHorizontalFacing().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.with(FACING, rot.rotate(state.get(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.toRotation(state.get(FACING)));
	}
}