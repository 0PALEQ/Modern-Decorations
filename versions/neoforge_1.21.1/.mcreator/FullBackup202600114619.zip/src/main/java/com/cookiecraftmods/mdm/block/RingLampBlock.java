package com.cookiecraftmods.mdm.block;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.IEnviromentBlockReader;
import net.minecraft.world.IBlockReader;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.block.material.Material;
import net.minecraft.block.SoundType;
import net.minecraft.block.BlockState;
import net.minecraft.block.Block;

public class RingLampBlock extends Block {
	private static final VoxelShape SHAPE = VoxelShapes.or(makeCuboidShape(4, 15, 4, 12, 16, 12), makeCuboidShape(4.25, 14, 4.25, 11.75, 15, 5.25), makeCuboidShape(4.25, 14, 10.75, 11.75, 15, 11.75), makeCuboidShape(4.25, 14, 5.25, 5.25, 15, 10.75),
			makeCuboidShape(10.75, 14, 5.25, 11.75, 15, 10.75), makeCuboidShape(5.5, 14.5, 5.5, 10.5, 15, 10.5));

	public RingLampBlock() {
		super(Block.Properties.create(Material.REDSTONE_LIGHT).sound(SoundType.GLASS).hardnessAndResistance(1f, 10f).lightValue(15));
	}

	@Override
	public boolean isSolid(BlockState state) {
		return false;
	}

	@Override
	public VoxelShape getShape(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext context) {
		return SHAPE;
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public BlockRenderLayer getRenderLayer() {
		return BlockRenderLayer.CUTOUT;
	}

	@Override
	public boolean isNormalCube(BlockState state, IBlockReader worldIn, BlockPos pos) {
		return false;
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public int getPackedLightmapCoords(BlockState state, IEnviromentBlockReader worldIn, BlockPos pos) {
		return 15728880;
	}

	@Override
	public boolean needsPostProcessing(BlockState state, IBlockReader worldIn, BlockPos pos) {
		return true;
	}

	@Override
	public VoxelShape getRaytraceShape(BlockState state, IBlockReader world, BlockPos pos) {
		return VoxelShapes.empty();
	}
}