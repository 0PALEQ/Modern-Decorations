
package com.cookiecraftmods.mdm.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class GreySofaBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public GreySofaBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM).sound(SoundType.WOOL).strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(0, 1, 0, 16, 16, 3), box(16, 1, 0, 19, 12, 16), box(-3, 1, 0, 0, 12, 16), box(0, 1, 3, 16, 7, 15), box(0.1, 7, 3, 15.9, 8, 14.75), box(0.3, 8, 3, 15.7, 9, 13.75), box(0.3, 9, 3, 15.7, 16, 4),
					box(0.8, 9, 4, 15.2, 15.5, 5), box(13, 0, 12, 15, 1, 14), box(1, 0, 1, 3, 1, 3), box(1, 0, 12, 3, 1, 14));
			case NORTH -> Shapes.or(box(0, 1, 13, 16, 16, 16), box(-3, 1, 0, 0, 12, 16), box(16, 1, 0, 19, 12, 16), box(0, 1, 1, 16, 7, 13), box(0.1, 7, 1.25, 15.9, 8, 13), box(0.3, 8, 2.25, 15.7, 9, 13), box(0.3, 9, 12, 15.7, 16, 13),
					box(0.8, 9, 11, 15.2, 15.5, 12), box(1, 0, 2, 3, 1, 4), box(13, 0, 13, 15, 1, 15), box(13, 0, 2, 15, 1, 4));
			case EAST -> Shapes.or(box(0, 1, 0, 3, 16, 16), box(0, 1, -3, 16, 12, 0), box(0, 1, 16, 16, 12, 19), box(3, 1, 0, 15, 7, 16), box(3, 7, 0.1, 14.75, 8, 15.9), box(3, 8, 0.3, 13.75, 9, 15.7), box(3, 9, 0.3, 4, 16, 15.7),
					box(4, 9, 0.8, 5, 15.5, 15.2), box(12, 0, 1, 14, 1, 3), box(1, 0, 13, 3, 1, 15), box(12, 0, 13, 14, 1, 15));
			case WEST -> Shapes.or(box(13, 1, 0, 16, 16, 16), box(0, 1, 16, 16, 12, 19), box(0, 1, -3, 16, 12, 0), box(1, 1, 0, 13, 7, 16), box(1.25, 7, 0.1, 13, 8, 15.9), box(2.25, 8, 0.3, 13, 9, 15.7), box(12, 9, 0.3, 13, 16, 15.7),
					box(11, 9, 0.8, 12, 15.5, 15.2), box(2, 0, 13, 4, 1, 15), box(13, 0, 1, 15, 1, 3), box(2, 0, 1, 4, 1, 3));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}
}
