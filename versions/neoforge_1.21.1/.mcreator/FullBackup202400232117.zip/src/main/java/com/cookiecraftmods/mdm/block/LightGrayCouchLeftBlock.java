
package com.cookiecraftmods.mdm.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class LightGrayCouchLeftBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public LightGrayCouchLeftBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM).sound(SoundType.WOOL).strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(3, 1, 0, 16, 15, 3), box(1, 1, 0, 3, 7, 14.25), box(0, 7, 0, 3, 10, 14.25), box(3, 3, 3, 16, 6, 14.25), box(3, 1, 3, 16, 3, 13.75), box(3.25, 6, 5, 15.75, 7, 13.5), box(3.75, 7, 5.5, 15.25, 7.5, 13),
					box(3.25, 5.31283, 3.04539, 15.75, 15.31283, 5.04539), box(3.75, 6.56283, 5.04539, 15.25, 14.81283, 5.54539), box(4, 0, 11, 6, 1, 13), box(4, 0, 1, 6, 1, 3));
			case NORTH -> Shapes.or(box(0, 1, 13, 13, 15, 16), box(13, 1, 1.75, 15, 7, 16), box(13, 7, 1.75, 16, 10, 16), box(0, 3, 1.75, 13, 6, 13), box(0, 1, 2.25, 13, 3, 13), box(0.25, 6, 2.5, 12.75, 7, 11), box(0.75, 7, 3, 12.25, 7.5, 10.5),
					box(0.25, 5.31283, 10.95461, 12.75, 15.31283, 12.95461), box(0.75, 6.56283, 10.45461, 12.25, 14.81283, 10.95461), box(10, 0, 3, 12, 1, 5), box(10, 0, 13, 12, 1, 15));
			case EAST -> Shapes.or(box(0, 1, 0, 3, 15, 13), box(0, 1, 13, 14.25, 7, 15), box(0, 7, 13, 14.25, 10, 16), box(3, 3, 0, 14.25, 6, 13), box(3, 1, 0, 13.75, 3, 13), box(5, 6, 0.25, 13.5, 7, 12.75), box(5.5, 7, 0.75, 13, 7.5, 12.25),
					box(3.04539, 5.31283, 0.25, 5.04539, 15.31283, 12.75), box(5.04539, 6.56283, 0.75, 5.54539, 14.81283, 12.25), box(11, 0, 10, 13, 1, 12), box(1, 0, 10, 3, 1, 12));
			case WEST -> Shapes.or(box(13, 1, 3, 16, 15, 16), box(1.75, 1, 1, 16, 7, 3), box(1.75, 7, 0, 16, 10, 3), box(1.75, 3, 3, 13, 6, 16), box(2.25, 1, 3, 13, 3, 16), box(2.5, 6, 3.25, 11, 7, 15.75), box(3, 7, 3.75, 10.5, 7.5, 15.25),
					box(10.95461, 5.31283, 3.25, 12.95461, 15.31283, 15.75), box(10.45461, 6.56283, 3.75, 10.95461, 14.81283, 15.25), box(3, 0, 4, 5, 1, 6), box(13, 0, 4, 15, 1, 6));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}
}
