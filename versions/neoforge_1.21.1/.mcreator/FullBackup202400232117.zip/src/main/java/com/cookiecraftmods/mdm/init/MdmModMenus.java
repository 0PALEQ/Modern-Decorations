
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package com.cookiecraftmods.mdm.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import com.cookiecraftmods.mdm.world.inventory.StorageMenu;
import com.cookiecraftmods.mdm.world.inventory.OvenGuiMenu;
import com.cookiecraftmods.mdm.world.inventory.FridgeGuiMenu;
import com.cookiecraftmods.mdm.world.inventory.FreezerguiMenu;
import com.cookiecraftmods.mdm.MdmMod;

public class MdmModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, MdmMod.MODID);
	public static final RegistryObject<MenuType<StorageMenu>> STORAGE = REGISTRY.register("storage", () -> IForgeMenuType.create(StorageMenu::new));
	public static final RegistryObject<MenuType<FreezerguiMenu>> FREEZERGUI = REGISTRY.register("freezergui", () -> IForgeMenuType.create(FreezerguiMenu::new));
	public static final RegistryObject<MenuType<FridgeGuiMenu>> FRIDGE_GUI = REGISTRY.register("fridge_gui", () -> IForgeMenuType.create(FridgeGuiMenu::new));
	public static final RegistryObject<MenuType<OvenGuiMenu>> OVEN_GUI = REGISTRY.register("oven_gui", () -> IForgeMenuType.create(OvenGuiMenu::new));
}
