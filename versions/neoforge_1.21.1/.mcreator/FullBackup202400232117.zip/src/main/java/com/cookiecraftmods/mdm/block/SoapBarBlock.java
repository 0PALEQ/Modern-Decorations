
package com.cookiecraftmods.mdm.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class SoapBarBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public SoapBarBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM).sound(SoundType.HONEY_BLOCK).strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(5, 0, 1, 11, 0.25, 5), box(5, 0.25, 1, 11, 0.5, 1.5), box(5, 0.25, 4.5, 11, 0.5, 5), box(10.5, 0.25, 1.5, 11, 0.5, 4.5), box(5, 0.25, 1.5, 5.5, 0.5, 4.5), box(6, 0.25, 2, 10, 1, 4));
			case NORTH -> Shapes.or(box(5, 0, 11, 11, 0.25, 15), box(5, 0.25, 14.5, 11, 0.5, 15), box(5, 0.25, 11, 11, 0.5, 11.5), box(5, 0.25, 11.5, 5.5, 0.5, 14.5), box(10.5, 0.25, 11.5, 11, 0.5, 14.5), box(6, 0.25, 12, 10, 1, 14));
			case EAST -> Shapes.or(box(1, 0, 5, 5, 0.25, 11), box(1, 0.25, 5, 1.5, 0.5, 11), box(4.5, 0.25, 5, 5, 0.5, 11), box(1.5, 0.25, 5, 4.5, 0.5, 5.5), box(1.5, 0.25, 10.5, 4.5, 0.5, 11), box(2, 0.25, 6, 4, 1, 10));
			case WEST -> Shapes.or(box(11, 0, 5, 15, 0.25, 11), box(14.5, 0.25, 5, 15, 0.5, 11), box(11, 0.25, 5, 11.5, 0.5, 11), box(11.5, 0.25, 10.5, 14.5, 0.5, 11), box(11.5, 0.25, 5, 14.5, 0.5, 5.5), box(12, 0.25, 6, 14, 1, 10));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}
}
