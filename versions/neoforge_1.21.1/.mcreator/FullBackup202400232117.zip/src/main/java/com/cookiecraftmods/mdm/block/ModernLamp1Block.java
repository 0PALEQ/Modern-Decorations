
package com.cookiecraftmods.mdm.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class ModernLamp1Block extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public ModernLamp1Block() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM).sound(SoundType.GLASS).strength(1f, 10f).lightLevel(s -> 15).noOcclusion().hasPostProcess((bs, br, bp) -> true).emissiveRendering((bs, br, bp) -> true)
				.isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(8, 0, 8, 12, 0.25, 12), box(4, 0, 4, 8, 0.25, 8), box(6, 0, 6, 10, 0.35, 10), box(9.9, 0.1, 9.9, 10.1, 21.1, 10.1), box(5.9, 0.1, 5.9, 6.1, 17.1, 6.1), box(7.9, 0.1, 7.9, 8.1, 26.1, 8.1),
					box(9, 19, 9, 11, 24, 11), box(5, 15, 5, 7, 20, 7), box(7, 23, 7, 9, 28, 9));
			case NORTH -> Shapes.or(box(4, 0, 4, 8, 0.25, 8), box(8, 0, 8, 12, 0.25, 12), box(6, 0, 6, 10, 0.35, 10), box(5.9, 0.1, 5.9, 6.1, 21.1, 6.1), box(9.9, 0.1, 9.9, 10.1, 17.1, 10.1), box(7.9, 0.1, 7.9, 8.1, 26.1, 8.1),
					box(5, 19, 5, 7, 24, 7), box(9, 15, 9, 11, 20, 11), box(7, 23, 7, 9, 28, 9));
			case EAST -> Shapes.or(box(8, 0, 4, 12, 0.25, 8), box(4, 0, 8, 8, 0.25, 12), box(6, 0, 6, 10, 0.35, 10), box(9.9, 0.1, 5.9, 10.1, 21.1, 6.1), box(5.9, 0.1, 9.9, 6.1, 17.1, 10.1), box(7.9, 0.1, 7.9, 8.1, 26.1, 8.1),
					box(9, 19, 5, 11, 24, 7), box(5, 15, 9, 7, 20, 11), box(7, 23, 7, 9, 28, 9));
			case WEST -> Shapes.or(box(4, 0, 8, 8, 0.25, 12), box(8, 0, 4, 12, 0.25, 8), box(6, 0, 6, 10, 0.35, 10), box(5.9, 0.1, 9.9, 6.1, 21.1, 10.1), box(9.9, 0.1, 5.9, 10.1, 17.1, 6.1), box(7.9, 0.1, 7.9, 8.1, 26.1, 8.1),
					box(5, 19, 9, 7, 24, 11), box(9, 15, 5, 11, 20, 7), box(7, 23, 7, 9, 28, 9));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}
}
