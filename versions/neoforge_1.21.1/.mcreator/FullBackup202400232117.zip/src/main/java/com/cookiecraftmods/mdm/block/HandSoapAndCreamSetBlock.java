
package com.cookiecraftmods.mdm.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class HandSoapAndCreamSetBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public HandSoapAndCreamSetBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM).sound(SoundType.BONE_BLOCK).strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(11, 0, 1, 15, 3, 5), box(12, 3, 2, 14, 4, 4), box(6, 0, 1.9, 10, 4, 5.9), box(7, 4, 2.9, 9, 5, 4.9), box(11.5, 0.5, 5, 14.5, 2.5, 5.025), box(6.5, 0.5, 5.9, 9.5, 2.5, 5.925), box(1, 0, 2, 5, 6, 5),
					box(2, 6, 2.5, 4, 7, 4.5), box(2.75, 7, 3.25, 3.25, 8, 3.75), box(2.75, 7.5, 3.75, 3.25, 8, 4.5), box(1.5, 1, 5, 4.5, 5, 5.025));
			case NORTH -> Shapes.or(box(1, 0, 11, 5, 3, 15), box(2, 3, 12, 4, 4, 14), box(6, 0, 10.1, 10, 4, 14.1), box(7, 4, 11.1, 9, 5, 13.1), box(1.5, 0.5, 10.975, 4.5, 2.5, 11), box(6.5, 0.5, 10.075, 9.5, 2.5, 10.1), box(11, 0, 11, 15, 6, 14),
					box(12, 6, 11.5, 14, 7, 13.5), box(12.75, 7, 12.25, 13.25, 8, 12.75), box(12.75, 7.5, 11.5, 13.25, 8, 12.25), box(11.5, 1, 10.975, 14.5, 5, 11));
			case EAST -> Shapes.or(box(1, 0, 1, 5, 3, 5), box(2, 3, 2, 4, 4, 4), box(1.9, 0, 6, 5.9, 4, 10), box(2.9, 4, 7, 4.9, 5, 9), box(5, 0.5, 1.5, 5.025, 2.5, 4.5), box(5.9, 0.5, 6.5, 5.925, 2.5, 9.5), box(2, 0, 11, 5, 6, 15),
					box(2.5, 6, 12, 4.5, 7, 14), box(3.25, 7, 12.75, 3.75, 8, 13.25), box(3.75, 7.5, 12.75, 4.5, 8, 13.25), box(5, 1, 11.5, 5.025, 5, 14.5));
			case WEST -> Shapes.or(box(11, 0, 11, 15, 3, 15), box(12, 3, 12, 14, 4, 14), box(10.1, 0, 6, 14.1, 4, 10), box(11.1, 4, 7, 13.1, 5, 9), box(10.975, 0.5, 11.5, 11, 2.5, 14.5), box(10.075, 0.5, 6.5, 10.1, 2.5, 9.5), box(11, 0, 1, 14, 6, 5),
					box(11.5, 6, 2, 13.5, 7, 4), box(12.25, 7, 2.75, 12.75, 8, 3.25), box(11.5, 7.5, 2.75, 12.25, 8, 3.25), box(10.975, 1, 1.5, 11, 5, 4.5));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}
}
