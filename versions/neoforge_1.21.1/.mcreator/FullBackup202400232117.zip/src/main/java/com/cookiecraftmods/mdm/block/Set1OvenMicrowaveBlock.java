
package com.cookiecraftmods.mdm.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class Set1OvenMicrowaveBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public Set1OvenMicrowaveBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM).sound(SoundType.STONE).strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(10, 1, 0.1, 11, 6, 16), box(0, 0, 0, 10, 32, 16), box(10, 7, 0.5, 11, 15, 15.5), box(10, 20, 0.5, 11, 28, 15.5), box(10, 28.5, 0.5, 11, 31, 15.5), box(10, 15.5, 0.5, 11, 18, 15.5), box(11.5, 13, 4, 12.5, 14, 12),
					box(11, 13, 11, 11.5, 14, 12), box(11, 13, 4, 11.5, 14, 5), box(11.5, 26, 4, 12.5, 27, 12), box(11, 26, 4, 11.5, 27, 5), box(11, 26, 11, 11.5, 27, 12));
			case NORTH -> Shapes.or(box(5, 1, 0, 6, 6, 15.9), box(6, 0, 0, 16, 32, 16), box(5, 7, 0.5, 6, 15, 15.5), box(5, 20, 0.5, 6, 28, 15.5), box(5, 28.5, 0.5, 6, 31, 15.5), box(5, 15.5, 0.5, 6, 18, 15.5), box(3.5, 13, 4, 4.5, 14, 12),
					box(4.5, 13, 4, 5, 14, 5), box(4.5, 13, 11, 5, 14, 12), box(3.5, 26, 4, 4.5, 27, 12), box(4.5, 26, 11, 5, 27, 12), box(4.5, 26, 4, 5, 27, 5));
			case EAST -> Shapes.or(box(0.1, 1, 5, 16, 6, 6), box(0, 0, 6, 16, 32, 16), box(0.5, 7, 5, 15.5, 15, 6), box(0.5, 20, 5, 15.5, 28, 6), box(0.5, 28.5, 5, 15.5, 31, 6), box(0.5, 15.5, 5, 15.5, 18, 6), box(4, 13, 3.5, 12, 14, 4.5),
					box(11, 13, 4.5, 12, 14, 5), box(4, 13, 4.5, 5, 14, 5), box(4, 26, 3.5, 12, 27, 4.5), box(4, 26, 4.5, 5, 27, 5), box(11, 26, 4.5, 12, 27, 5));
			case WEST -> Shapes.or(box(0, 1, 10, 15.9, 6, 11), box(0, 0, 0, 16, 32, 10), box(0.5, 7, 10, 15.5, 15, 11), box(0.5, 20, 10, 15.5, 28, 11), box(0.5, 28.5, 10, 15.5, 31, 11), box(0.5, 15.5, 10, 15.5, 18, 11),
					box(4, 13, 11.5, 12, 14, 12.5), box(4, 13, 11, 5, 14, 11.5), box(11, 13, 11, 12, 14, 11.5), box(4, 26, 11.5, 12, 27, 12.5), box(11, 26, 11, 12, 27, 11.5), box(4, 26, 11, 5, 27, 11.5));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}
}
