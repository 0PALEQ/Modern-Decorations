
package com.cookiecraftmods.mdm.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class ModernChandelier1Block extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public ModernChandelier1Block() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM).sound(SoundType.GLASS).strength(1f, 10f).lightLevel(s -> 15).noOcclusion().hasPostProcess((bs, br, bp) -> true).emissiveRendering((bs, br, bp) -> true)
				.isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(4, 15.775, 8, 8, 16.025, 12), box(8, 15.775, 4, 12, 16.025, 8), box(6, 15.675, 6, 10, 16.025, 10), box(5.9, 9.925, 9.9, 6.1, 15.925, 10.1), box(9.9, 11.925, 5.9, 10.1, 15.925, 6.1),
					box(7.9, 4.925, 7.9, 8.1, 15.925, 8.1), box(5, 5.025, 9, 7, 10.025, 11), box(9, 8.025, 5, 11, 13.025, 7), box(7, 1.025, 7, 9, 6.025, 9));
			case NORTH -> Shapes.or(box(8, 15.775, 4, 12, 16.025, 8), box(4, 15.775, 8, 8, 16.025, 12), box(6, 15.675, 6, 10, 16.025, 10), box(9.9, 9.925, 5.9, 10.1, 15.925, 6.1), box(5.9, 11.925, 9.9, 6.1, 15.925, 10.1),
					box(7.9, 4.925, 7.9, 8.1, 15.925, 8.1), box(9, 5.025, 5, 11, 10.025, 7), box(5, 8.025, 9, 7, 13.025, 11), box(7, 1.025, 7, 9, 6.025, 9));
			case EAST -> Shapes.or(box(8, 15.775, 8, 12, 16.025, 12), box(4, 15.775, 4, 8, 16.025, 8), box(6, 15.675, 6, 10, 16.025, 10), box(9.9, 9.925, 9.9, 10.1, 15.925, 10.1), box(5.9, 11.925, 5.9, 6.1, 15.925, 6.1),
					box(7.9, 4.925, 7.9, 8.1, 15.925, 8.1), box(9, 5.025, 9, 11, 10.025, 11), box(5, 8.025, 5, 7, 13.025, 7), box(7, 1.025, 7, 9, 6.025, 9));
			case WEST -> Shapes.or(box(4, 15.775, 4, 8, 16.025, 8), box(8, 15.775, 8, 12, 16.025, 12), box(6, 15.675, 6, 10, 16.025, 10), box(5.9, 9.925, 5.9, 6.1, 15.925, 6.1), box(9.9, 11.925, 9.9, 10.1, 15.925, 10.1),
					box(7.9, 4.925, 7.9, 8.1, 15.925, 8.1), box(5, 5.025, 5, 7, 10.025, 7), box(9, 8.025, 9, 11, 13.025, 11), box(7, 1.025, 7, 9, 6.025, 9));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}
}
