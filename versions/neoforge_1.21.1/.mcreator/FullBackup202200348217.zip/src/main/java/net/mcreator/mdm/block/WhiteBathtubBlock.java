
package net.mcreator.mdm.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.List;
import java.util.Collections;

public class WhiteBathtubBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public WhiteBathtubBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM).sound(SoundType.METAL).strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(0, 1, -16, 16, 2, 16), box(0, 2, -16, 2, 16, 16), box(14, 2, -16, 16, 16, 16), box(2, 2, 14, 14, 16, 16), box(2, 2, -16, 14, 16, -13), box(7, 2, -10, 9, 2.25, -8), box(6.75, 2.25, -10.25, 9.25, 2.5, -7.75),
					box(14.25, 0, 14.25, 15.75, 1, 15.75), box(0.25, 0, 14.25, 1.75, 1, 15.75), box(0.25, 0, -15.75, 1.75, 1, -14.25), box(14.25, 0, -15.75, 15.75, 1, -14.25));
			case NORTH -> Shapes.or(box(0, 1, 0, 16, 2, 32), box(14, 2, 0, 16, 16, 32), box(0, 2, 0, 2, 16, 32), box(2, 2, 0, 14, 16, 2), box(2, 2, 29, 14, 16, 32), box(7, 2, 24, 9, 2.25, 26), box(6.75, 2.25, 23.75, 9.25, 2.5, 26.25),
					box(0.25, 0, 0.25, 1.75, 1, 1.75), box(14.25, 0, 0.25, 15.75, 1, 1.75), box(14.25, 0, 30.25, 15.75, 1, 31.75), box(0.25, 0, 30.25, 1.75, 1, 31.75));
			case EAST -> Shapes.or(box(-16, 1, 0, 16, 2, 16), box(-16, 2, 14, 16, 16, 16), box(-16, 2, 0, 16, 16, 2), box(14, 2, 2, 16, 16, 14), box(-16, 2, 2, -13, 16, 14), box(-10, 2, 7, -8, 2.25, 9), box(-10.25, 2.25, 6.75, -7.75, 2.5, 9.25),
					box(14.25, 0, 0.25, 15.75, 1, 1.75), box(14.25, 0, 14.25, 15.75, 1, 15.75), box(-15.75, 0, 14.25, -14.25, 1, 15.75), box(-15.75, 0, 0.25, -14.25, 1, 1.75));
			case WEST -> Shapes.or(box(0, 1, 0, 32, 2, 16), box(0, 2, 0, 32, 16, 2), box(0, 2, 14, 32, 16, 16), box(0, 2, 2, 2, 16, 14), box(29, 2, 2, 32, 16, 14), box(24, 2, 7, 26, 2.25, 9), box(23.75, 2.25, 6.75, 26.25, 2.5, 9.25),
					box(0.25, 0, 14.25, 1.75, 1, 15.75), box(0.25, 0, 0.25, 1.75, 1, 1.75), box(30.25, 0, 0.25, 31.75, 1, 1.75), box(30.25, 0, 14.25, 31.75, 1, 15.75));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public List<ItemStack> getDrops(BlockState state, LootParams.Builder builder) {
		List<ItemStack> dropsOriginal = super.getDrops(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new ItemStack(this, 1));
	}
}
