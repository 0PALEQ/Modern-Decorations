
package net.mcreator.mdm.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.List;
import java.util.Collections;

public class Set1CornerCabinet2Block extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public Set1CornerCabinet2Block() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM).sound(SoundType.STONE).strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(7, 17, 0, 16, 18, 16), box(8, 0, 0, 16, 17, 1), box(8, 0, 1, 15, 17, 16), box(7, 15, 0, 8, 17, 16), box(15, 15, 1, 16, 17, 16), box(0.1, 1, 13, 6.1, 14.9, 14), box(0, 0, 0, 8, 15, 13), box(0, 15, 0, 7, 16, 15));
			case NORTH -> Shapes.or(box(0, 17, 0, 9, 18, 16), box(0, 0, 15, 8, 17, 16), box(1, 0, 0, 8, 17, 15), box(8, 15, 0, 9, 17, 16), box(0, 15, 0, 1, 17, 15), box(9.9, 1, 2, 15.9, 14.9, 3), box(8, 0, 3, 16, 15, 16), box(9, 15, 1, 16, 16, 16));
			case EAST -> Shapes.or(box(0, 17, 0, 16, 18, 9), box(0, 0, 0, 1, 17, 8), box(1, 0, 1, 16, 17, 8), box(0, 15, 8, 16, 17, 9), box(1, 15, 0, 16, 17, 1), box(13, 1, 9.9, 14, 14.9, 15.9), box(0, 0, 8, 13, 15, 16), box(0, 15, 9, 15, 16, 16));
			case WEST -> Shapes.or(box(0, 17, 7, 16, 18, 16), box(15, 0, 8, 16, 17, 16), box(0, 0, 8, 15, 17, 15), box(0, 15, 7, 16, 17, 8), box(0, 15, 15, 15, 17, 16), box(2, 1, 0.1, 3, 14.9, 6.1), box(3, 0, 0, 16, 15, 8), box(1, 15, 0, 16, 16, 7));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public List<ItemStack> getDrops(BlockState state, LootParams.Builder builder) {
		List<ItemStack> dropsOriginal = super.getDrops(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new ItemStack(this, 1));
	}
}
