
package net.mcreator.mdm.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class KitchenTabIconItem extends Item {
	public KitchenTabIconItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.EPIC));
	}

	@Override
	public int getEnchantmentValue() {
		return 1;
	}
}
