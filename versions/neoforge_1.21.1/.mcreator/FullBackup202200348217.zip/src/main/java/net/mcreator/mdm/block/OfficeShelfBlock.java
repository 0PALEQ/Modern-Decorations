
package net.mcreator.mdm.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.List;
import java.util.Collections;

public class OfficeShelfBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public OfficeShelfBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM).sound(SoundType.WOOD).strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(12, 3, 1, 12.25, 30.75, 12), box(3.5, 3, 1, 3.75, 30.75, 12), box(0.5, 2.75, 1, 15.5, 3, 13), box(0.5, 6.75, 1, 15.5, 7, 13), box(0.5, 10.75, 1, 15.5, 11, 13), box(0.5, 14.75, 1, 15.5, 15, 13),
					box(0.5, 18.75, 1, 15.5, 19, 13), box(0.5, 22.75, 1, 15.5, 23, 13), box(0.5, 26.75, 1, 15.5, 27, 13), box(0, 0, 0, 16, 31, 1), box(15.5, 0, 1, 16, 31, 13), box(0, 0, 1, 0.5, 31, 13), box(0.5, 30.75, 1, 15.5, 31, 13));
			case NORTH -> Shapes.or(box(3.75, 3, 4, 4, 30.75, 15), box(12.25, 3, 4, 12.5, 30.75, 15), box(0.5, 2.75, 3, 15.5, 3, 15), box(0.5, 6.75, 3, 15.5, 7, 15), box(0.5, 10.75, 3, 15.5, 11, 15), box(0.5, 14.75, 3, 15.5, 15, 15),
					box(0.5, 18.75, 3, 15.5, 19, 15), box(0.5, 22.75, 3, 15.5, 23, 15), box(0.5, 26.75, 3, 15.5, 27, 15), box(0, 0, 15, 16, 31, 16), box(0, 0, 3, 0.5, 31, 15), box(15.5, 0, 3, 16, 31, 15), box(0.5, 30.75, 3, 15.5, 31, 15));
			case EAST -> Shapes.or(box(1, 3, 3.75, 12, 30.75, 4), box(1, 3, 12.25, 12, 30.75, 12.5), box(1, 2.75, 0.5, 13, 3, 15.5), box(1, 6.75, 0.5, 13, 7, 15.5), box(1, 10.75, 0.5, 13, 11, 15.5), box(1, 14.75, 0.5, 13, 15, 15.5),
					box(1, 18.75, 0.5, 13, 19, 15.5), box(1, 22.75, 0.5, 13, 23, 15.5), box(1, 26.75, 0.5, 13, 27, 15.5), box(0, 0, 0, 1, 31, 16), box(1, 0, 0, 13, 31, 0.5), box(1, 0, 15.5, 13, 31, 16), box(1, 30.75, 0.5, 13, 31, 15.5));
			case WEST -> Shapes.or(box(4, 3, 12, 15, 30.75, 12.25), box(4, 3, 3.5, 15, 30.75, 3.75), box(3, 2.75, 0.5, 15, 3, 15.5), box(3, 6.75, 0.5, 15, 7, 15.5), box(3, 10.75, 0.5, 15, 11, 15.5), box(3, 14.75, 0.5, 15, 15, 15.5),
					box(3, 18.75, 0.5, 15, 19, 15.5), box(3, 22.75, 0.5, 15, 23, 15.5), box(3, 26.75, 0.5, 15, 27, 15.5), box(15, 0, 0, 16, 31, 16), box(3, 0, 15.5, 15, 31, 16), box(3, 0, 0, 15, 31, 0.5), box(3, 30.75, 0.5, 15, 31, 15.5));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public List<ItemStack> getDrops(BlockState state, LootParams.Builder builder) {
		List<ItemStack> dropsOriginal = super.getDrops(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new ItemStack(this, 1));
	}
}
