
package net.mcreator.mdm.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.List;
import java.util.Collections;

public class RedModernStairsBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public RedModernStairsBlock() {
		super(BlockBehaviour.Properties.of().ignitedByLava().instrument(NoteBlockInstrument.BASS).sound(SoundType.WOOD).strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(6.5, 7, 3.5, 7.5, 14.75, 4.5), box(0, 6.75, 11.5, 14, 7, 12.5), box(6.5, 6, 3.5, 7.5, 7, 12.475), box(0, 14.75, 3.5, 14, 15, 4.5), box(1, 7, 8, 15, 8, 15), box(1, 15, 0, 15, 16, 7));
			case NORTH -> Shapes.or(box(8.5, 7, 11.5, 9.5, 14.75, 12.5), box(2, 6.75, 3.5, 16, 7, 4.5), box(8.5, 6, 3.525, 9.5, 7, 12.5), box(2, 14.75, 11.5, 16, 15, 12.5), box(1, 7, 1, 15, 8, 8), box(1, 15, 9, 15, 16, 16));
			case EAST -> Shapes.or(box(3.5, 7, 8.5, 4.5, 14.75, 9.5), box(11.5, 6.75, 2, 12.5, 7, 16), box(3.5, 6, 8.5, 12.475, 7, 9.5), box(3.5, 14.75, 2, 4.5, 15, 16), box(8, 7, 1, 15, 8, 15), box(0, 15, 1, 7, 16, 15));
			case WEST -> Shapes.or(box(11.5, 7, 6.5, 12.5, 14.75, 7.5), box(3.5, 6.75, 0, 4.5, 7, 14), box(3.525, 6, 6.5, 12.5, 7, 7.5), box(11.5, 14.75, 0, 12.5, 15, 14), box(1, 7, 1, 8, 8, 15), box(9, 15, 1, 16, 16, 15));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public List<ItemStack> getDrops(BlockState state, LootParams.Builder builder) {
		List<ItemStack> dropsOriginal = super.getDrops(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new ItemStack(this, 1));
	}
}
