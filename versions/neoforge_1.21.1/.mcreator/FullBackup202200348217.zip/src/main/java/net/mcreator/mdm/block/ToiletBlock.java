
package net.mcreator.mdm.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.List;
import java.util.Collections;

public class ToiletBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public ToiletBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM).sound(SoundType.DEEPSLATE_TILES).strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default ->
				Shapes.or(box(6, 3, 0, 10, 5, 2), box(6, 22, 0, 8, 24, 0.05), box(5, 21, 0, 11, 25, 0.025), box(9, 22, 0, 10, 24, 0.05), box(5, 5, 0, 11, 6, 9), box(3, 6, 0, 13, 9, 13), box(3, 9.25, 1, 13, 10.25, 13), box(4, 9, 1.5, 12, 9.25, 12));
			case NORTH -> Shapes.or(box(6, 3, 14, 10, 5, 16), box(8, 22, 15.95, 10, 24, 16), box(5, 21, 15.975, 11, 25, 16), box(6, 22, 15.95, 7, 24, 16), box(5, 5, 7, 11, 6, 16), box(3, 6, 3, 13, 9, 16), box(3, 9.25, 3, 13, 10.25, 15),
					box(4, 9, 4, 12, 9.25, 14.5));
			case EAST ->
				Shapes.or(box(0, 3, 6, 2, 5, 10), box(0, 22, 8, 0.05, 24, 10), box(0, 21, 5, 0.025, 25, 11), box(0, 22, 6, 0.05, 24, 7), box(0, 5, 5, 9, 6, 11), box(0, 6, 3, 13, 9, 13), box(1, 9.25, 3, 13, 10.25, 13), box(1.5, 9, 4, 12, 9.25, 12));
			case WEST -> Shapes.or(box(14, 3, 6, 16, 5, 10), box(15.95, 22, 6, 16, 24, 8), box(15.975, 21, 5, 16, 25, 11), box(15.95, 22, 9, 16, 24, 10), box(7, 5, 5, 16, 6, 11), box(3, 6, 3, 16, 9, 13), box(3, 9.25, 3, 15, 10.25, 13),
					box(4, 9, 4, 14.5, 9.25, 12));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public List<ItemStack> getDrops(BlockState state, LootParams.Builder builder) {
		List<ItemStack> dropsOriginal = super.getDrops(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new ItemStack(this, 1));
	}
}
