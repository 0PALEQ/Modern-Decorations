
package net.mcreator.mdm.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.List;
import java.util.Collections;

public class BlackDeskLampBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public BlackDeskLampBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM).sound(SoundType.GLASS).strength(1f, 10f).lightLevel(s -> 15).noOcclusion().hasPostProcess((bs, br, bp) -> true).emissiveRendering((bs, br, bp) -> true)
				.isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(5, 0, 4, 11, 1, 7), box(7.5, 0.25, 5, 8.5, 8, 6), box(7.525, 6.75, 4.85, 8.475, 12.25, 5.85), box(5, 11, 8.5, 11, 12, 12.75), box(6, 10.9, 9.5, 10, 11, 12.5), box(7.425, 7.75, 5.35, 8.575, 8.25, 5.85),
					box(9.5, 0, 5.25, 9.75, 2, 5.5));
			case NORTH -> Shapes.or(box(5, 0, 9, 11, 1, 12), box(7.5, 0.25, 10, 8.5, 8, 11), box(7.525, 6.75, 10.15, 8.475, 12.25, 11.15), box(5, 11, 3.25, 11, 12, 7.5), box(6, 10.9, 3.5, 10, 11, 6.5), box(7.425, 7.75, 10.15, 8.575, 8.25, 10.65),
					box(6.25, 0, 10.5, 6.5, 2, 10.75));
			case EAST -> Shapes.or(box(4, 0, 5, 7, 1, 11), box(5, 0.25, 7.5, 6, 8, 8.5), box(4.85, 6.75, 7.525, 5.85, 12.25, 8.475), box(8.5, 11, 5, 12.75, 12, 11), box(9.5, 10.9, 6, 12.5, 11, 10), box(5.35, 7.75, 7.425, 5.85, 8.25, 8.575),
					box(5.25, 0, 6.25, 5.5, 2, 6.5));
			case WEST -> Shapes.or(box(9, 0, 5, 12, 1, 11), box(10, 0.25, 7.5, 11, 8, 8.5), box(10.15, 6.75, 7.525, 11.15, 12.25, 8.475), box(3.25, 11, 5, 7.5, 12, 11), box(3.5, 10.9, 6, 6.5, 11, 10), box(10.15, 7.75, 7.425, 10.65, 8.25, 8.575),
					box(10.5, 0, 9.5, 10.75, 2, 9.75));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public List<ItemStack> getDrops(BlockState state, LootParams.Builder builder) {
		List<ItemStack> dropsOriginal = super.getDrops(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new ItemStack(this, 1));
	}
}
