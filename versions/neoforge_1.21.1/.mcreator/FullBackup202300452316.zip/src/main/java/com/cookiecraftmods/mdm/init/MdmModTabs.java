
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.cookiecraftmods.mdm.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import com.cookiecraftmods.mdm.MdmMod;

public class MdmModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MdmMod.MODID);
	public static final RegistryObject<CreativeModeTab> OFFICE = REGISTRY.register("office",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.mdm.office")).icon(() -> new ItemStack(MdmModBlocks.BLACK_OFFICE_DESK.get())).displayItems((parameters, tabData) -> {
				tabData.accept(MdmModBlocks.BLACK_MODER_STAIRS.get().asItem());
				tabData.accept(MdmModBlocks.WHITE_MODERN_STAIRS.get().asItem());
				tabData.accept(MdmModBlocks.RED_MODERN_STAIRS.get().asItem());
				tabData.accept(MdmModBlocks.BLUE_MODERN_STAIRS.get().asItem());
				tabData.accept(MdmModBlocks.GREEN_MODERN_STAIRS.get().asItem());
				tabData.accept(MdmModBlocks.BLACK_OFFICE_DESK.get().asItem());
				tabData.accept(MdmModBlocks.BLACK_DESK_EXTENSION_1.get().asItem());
				tabData.accept(MdmModBlocks.BLACK_DESK_EXTENSION_2.get().asItem());
				tabData.accept(MdmModBlocks.BLACK_DESK_EXTENSION_3.get().asItem());
				tabData.accept(MdmModBlocks.OFFICE_CABINET_1.get().asItem());
				tabData.accept(MdmModBlocks.OFFICE_CABINET_2.get().asItem());
				tabData.accept(MdmModBlocks.OFFICE_CABINET_3.get().asItem());
				tabData.accept(MdmModBlocks.OFFICE_SHELF.get().asItem());
				tabData.accept(MdmModBlocks.MODERN_DESK_1.get().asItem());
				tabData.accept(MdmModBlocks.MODERN_DESK_2.get().asItem());
				tabData.accept(MdmModBlocks.SHELF.get().asItem());
				tabData.accept(MdmModBlocks.HANGING_SHELF.get().asItem());
				tabData.accept(MdmModBlocks.DOCUMENT_FOLDERS.get().asItem());
				tabData.accept(MdmModBlocks.TV_STAND_MID.get().asItem());
				tabData.accept(MdmModBlocks.TV_STAND_LEFT.get().asItem());
				tabData.accept(MdmModBlocks.TV_STAND_RIGHT.get().asItem());
				tabData.accept(MdmModBlocks.TV_STAND_MID_DECORATED.get().asItem());
				tabData.accept(MdmModBlocks.STEEL_SHELF.get().asItem());
				tabData.accept(MdmModBlocks.BLACK_LAMP.get().asItem());
				tabData.accept(MdmModBlocks.COUCHLEFT.get().asItem());
				tabData.accept(MdmModBlocks.COUCHMIDDLE.get().asItem());
				tabData.accept(MdmModBlocks.COUCH_RIGHT.get().asItem());
				tabData.accept(MdmModBlocks.COUCH_CORNER.get().asItem());
				tabData.accept(MdmModBlocks.SOFA.get().asItem());
				tabData.accept(MdmModBlocks.BLACK_MODERN_FRIDGE_1.get().asItem());
				tabData.accept(MdmModBlocks.LEAFLESS_BAMBOO_DECORATION_1.get().asItem());
				tabData.accept(MdmModBlocks.LEAFLESS_BAMBOO_DECORATION_2.get().asItem());
				tabData.accept(MdmModBlocks.LEAFLESS_BAMBOO_DECORATION_3.get().asItem());
				tabData.accept(MdmModBlocks.SET_1_CABINET.get().asItem());
				tabData.accept(MdmModBlocks.SET_1_CABINET_WITH_DRAWERS.get().asItem());
				tabData.accept(MdmModBlocks.SET_1_CORNER_CABINET_1.get().asItem());
				tabData.accept(MdmModBlocks.SET_1_CORNER_CABINET_2.get().asItem());
				tabData.accept(MdmModBlocks.SET_1_ISLAND_1.get().asItem());
				tabData.accept(MdmModBlocks.SET_1_ISLAND_2.get().asItem());
				tabData.accept(MdmModBlocks.SET_1_OVEN_MICROWAVE.get().asItem());
				tabData.accept(MdmModBlocks.SET_1_FRIDGE.get().asItem());
				tabData.accept(MdmModBlocks.SET_1_CABINET_2.get().asItem());
				tabData.accept(MdmModBlocks.SET_1_HANGING_CABINET.get().asItem());
				tabData.accept(MdmModBlocks.SET_1_CORNER_HANGING_CABINET.get().asItem());
				tabData.accept(MdmModBlocks.SET_2_CABINET_1.get().asItem());
				tabData.accept(MdmModBlocks.SET_2_CABINET_2.get().asItem());
				tabData.accept(MdmModBlocks.SET_2_CABINET_3.get().asItem());
				tabData.accept(MdmModBlocks.SET_2_CABINET_WITH_DRAWERS.get().asItem());
				tabData.accept(MdmModBlocks.SET_2_HANGING_SHELF.get().asItem());
				tabData.accept(MdmModBlocks.SET_2_CORNER_COUNTER.get().asItem());
				tabData.accept(MdmModBlocks.BASKETS.get().asItem());
				tabData.accept(MdmModBlocks.OVEN.get().asItem());
				tabData.accept(MdmModBlocks.INDUCTION_COOKER.get().asItem());
				tabData.accept(MdmModBlocks.HAND_SOAP_AND_CREAM_SET.get().asItem());
				tabData.accept(MdmModBlocks.TOILET_PAPER_ROLL.get().asItem());
				tabData.accept(MdmModBlocks.SOAP_BAR.get().asItem());
				tabData.accept(MdmModBlocks.TOILET.get().asItem());
				tabData.accept(MdmModBlocks.BATHROOM_SINK.get().asItem());
				tabData.accept(MdmModBlocks.BATHROOM_SINK_WITH_SHELF.get().asItem());
				tabData.accept(MdmModBlocks.BLACK_WASHBASIN_TAP.get().asItem());
				tabData.accept(MdmModBlocks.WHITE_BATHROOM_SHELF.get().asItem());
				tabData.accept(MdmModBlocks.RING_LAMP.get().asItem());
				tabData.accept(MdmModBlocks.WHITE_BATHTUB.get().asItem());
				tabData.accept(MdmModBlocks.TOWEL_SET_1.get().asItem());
				tabData.accept(MdmModBlocks.TOOTHBRUSHES.get().asItem());
				tabData.accept(MdmModBlocks.CHLOTHESBIN.get().asItem());
				tabData.accept(MdmModBlocks.BATHROOM_STAND.get().asItem());
				tabData.accept(MdmModBlocks.PILE_OF_TOWELS.get().asItem());
				tabData.accept(MdmModBlocks.WALKIN_SHOWER.get().asItem());
				tabData.accept(MdmModBlocks.RAIN_SHOWER.get().asItem());
				tabData.accept(MdmModBlocks.BATHROOM_MIRROR.get().asItem());
				tabData.accept(MdmModBlocks.CARPET_1.get().asItem());
				tabData.accept(MdmModBlocks.BLACK_DESK_LAMP.get().asItem());
				tabData.accept(MdmModBlocks.MODERN_LAMP_1.get().asItem());
				tabData.accept(MdmModBlocks.MODERN_DESK_LAMP_1.get().asItem());
				tabData.accept(MdmModBlocks.MODERN_CHANDELIER_1.get().asItem());
				tabData.accept(MdmModBlocks.CEILLING_FAN.get().asItem());
				tabData.accept(MdmModBlocks.POOL_TABLE.get().asItem());
				tabData.accept(MdmModBlocks.POTTED_TREE.get().asItem());
				tabData.accept(MdmModBlocks.OUTDOOR_COUCH.get().asItem());
				tabData.accept(MdmModBlocks.OUTDOOR_TABLE.get().asItem());
				tabData.accept(MdmModBlocks.LANTERN.get().asItem());
				tabData.accept(MdmModBlocks.STREET_LANTERN_BOTTOM.get().asItem());
				tabData.accept(MdmModBlocks.STREET_LANTERN_MID.get().asItem());
				tabData.accept(MdmModBlocks.STREET_LATERN_TOP.get().asItem());
				tabData.accept(MdmModBlocks.SET_1_NIGHT_TABLE.get().asItem());
				tabData.accept(MdmModBlocks.SET_1_BED.get().asItem());
				tabData.accept(MdmModBlocks.SET_1_FOOTREST.get().asItem());
			}).withSearchBar().build());
}
