
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.cookiecraftmods.mdm.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

import com.cookiecraftmods.mdm.block.entity.Set2HangingShelfBlockEntity;
import com.cookiecraftmods.mdm.block.entity.Set2CornerCounterBlockEntity;
import com.cookiecraftmods.mdm.block.entity.Set2CabinetWithDrawersBlockEntity;
import com.cookiecraftmods.mdm.block.entity.Set2Cabinet3BlockEntity;
import com.cookiecraftmods.mdm.block.entity.Set2Cabinet2BlockEntity;
import com.cookiecraftmods.mdm.block.entity.Set2Cabinet1BlockEntity;
import com.cookiecraftmods.mdm.block.entity.Set1Island2BlockEntity;
import com.cookiecraftmods.mdm.block.entity.Set1Island1BlockEntity;
import com.cookiecraftmods.mdm.block.entity.Set1FridgeBlockEntity;
import com.cookiecraftmods.mdm.block.entity.Set1CornerCabinet2BlockEntity;
import com.cookiecraftmods.mdm.block.entity.Set1CornerCabinet1BlockEntity;
import com.cookiecraftmods.mdm.block.entity.Set1CabinetWithDrawersBlockEntity;
import com.cookiecraftmods.mdm.block.entity.Set1CabinetBlockEntity;
import com.cookiecraftmods.mdm.block.entity.Set1Cabinet2BlockEntity;
import com.cookiecraftmods.mdm.MdmMod;

public class MdmModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, MdmMod.MODID);
	public static final RegistryObject<BlockEntityType<?>> SET_1_CABINET = register("set_1_cabinet", MdmModBlocks.SET_1_CABINET, Set1CabinetBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> SET_1_CABINET_WITH_DRAWERS = register("set_1_cabinet_with_drawers", MdmModBlocks.SET_1_CABINET_WITH_DRAWERS, Set1CabinetWithDrawersBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> SET_1_CORNER_CABINET_1 = register("set_1_corner_cabinet_1", MdmModBlocks.SET_1_CORNER_CABINET_1, Set1CornerCabinet1BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> SET_1_CORNER_CABINET_2 = register("set_1_corner_cabinet_2", MdmModBlocks.SET_1_CORNER_CABINET_2, Set1CornerCabinet2BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> SET_1_ISLAND_1 = register("set_1_island_1", MdmModBlocks.SET_1_ISLAND_1, Set1Island1BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> SET_1_ISLAND_2 = register("set_1_island_2", MdmModBlocks.SET_1_ISLAND_2, Set1Island2BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> SET_1_FRIDGE = register("set_1_fridge", MdmModBlocks.SET_1_FRIDGE, Set1FridgeBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> SET_1_CABINET_2 = register("set_1_cabinet_2", MdmModBlocks.SET_1_CABINET_2, Set1Cabinet2BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> SET_2_CABINET_1 = register("set_2_cabinet_1", MdmModBlocks.SET_2_CABINET_1, Set2Cabinet1BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> SET_2_CABINET_2 = register("set_2_cabinet_2", MdmModBlocks.SET_2_CABINET_2, Set2Cabinet2BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> SET_2_CABINET_3 = register("set_2_cabinet_3", MdmModBlocks.SET_2_CABINET_3, Set2Cabinet3BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> SET_2_CABINET_WITH_DRAWERS = register("set_2_cabinet_with_drawers", MdmModBlocks.SET_2_CABINET_WITH_DRAWERS, Set2CabinetWithDrawersBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> SET_2_HANGING_SHELF = register("set_2_hanging_shelf", MdmModBlocks.SET_2_HANGING_SHELF, Set2HangingShelfBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> SET_2_CORNER_COUNTER = register("set_2_corner_counter", MdmModBlocks.SET_2_CORNER_COUNTER, Set2CornerCounterBlockEntity::new);

	private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}
