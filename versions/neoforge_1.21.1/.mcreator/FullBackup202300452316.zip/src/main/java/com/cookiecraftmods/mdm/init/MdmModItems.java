
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.cookiecraftmods.mdm.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import com.cookiecraftmods.mdm.MdmMod;

public class MdmModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MdmMod.MODID);
	public static final RegistryObject<Item> BLACK_MODER_STAIRS = block(MdmModBlocks.BLACK_MODER_STAIRS);
	public static final RegistryObject<Item> WHITE_MODERN_STAIRS = block(MdmModBlocks.WHITE_MODERN_STAIRS);
	public static final RegistryObject<Item> RED_MODERN_STAIRS = block(MdmModBlocks.RED_MODERN_STAIRS);
	public static final RegistryObject<Item> BLUE_MODERN_STAIRS = block(MdmModBlocks.BLUE_MODERN_STAIRS);
	public static final RegistryObject<Item> GREEN_MODERN_STAIRS = block(MdmModBlocks.GREEN_MODERN_STAIRS);
	public static final RegistryObject<Item> BLACK_OFFICE_DESK = block(MdmModBlocks.BLACK_OFFICE_DESK);
	public static final RegistryObject<Item> BLACK_DESK_EXTENSION_1 = block(MdmModBlocks.BLACK_DESK_EXTENSION_1);
	public static final RegistryObject<Item> BLACK_DESK_EXTENSION_2 = block(MdmModBlocks.BLACK_DESK_EXTENSION_2);
	public static final RegistryObject<Item> BLACK_DESK_EXTENSION_3 = block(MdmModBlocks.BLACK_DESK_EXTENSION_3);
	public static final RegistryObject<Item> OFFICE_CABINET_1 = block(MdmModBlocks.OFFICE_CABINET_1);
	public static final RegistryObject<Item> OFFICE_CABINET_2 = block(MdmModBlocks.OFFICE_CABINET_2);
	public static final RegistryObject<Item> OFFICE_CABINET_3 = block(MdmModBlocks.OFFICE_CABINET_3);
	public static final RegistryObject<Item> OFFICE_SHELF = block(MdmModBlocks.OFFICE_SHELF);
	public static final RegistryObject<Item> MODERN_DESK_1 = block(MdmModBlocks.MODERN_DESK_1);
	public static final RegistryObject<Item> MODERN_DESK_2 = block(MdmModBlocks.MODERN_DESK_2);
	public static final RegistryObject<Item> SHELF = block(MdmModBlocks.SHELF);
	public static final RegistryObject<Item> HANGING_SHELF = block(MdmModBlocks.HANGING_SHELF);
	public static final RegistryObject<Item> DOCUMENT_FOLDERS = block(MdmModBlocks.DOCUMENT_FOLDERS);
	public static final RegistryObject<Item> TV_STAND_MID = block(MdmModBlocks.TV_STAND_MID);
	public static final RegistryObject<Item> TV_STAND_LEFT = block(MdmModBlocks.TV_STAND_LEFT);
	public static final RegistryObject<Item> TV_STAND_RIGHT = block(MdmModBlocks.TV_STAND_RIGHT);
	public static final RegistryObject<Item> TV_STAND_MID_DECORATED = block(MdmModBlocks.TV_STAND_MID_DECORATED);
	public static final RegistryObject<Item> STEEL_SHELF = block(MdmModBlocks.STEEL_SHELF);
	public static final RegistryObject<Item> BLACK_LAMP = block(MdmModBlocks.BLACK_LAMP);
	public static final RegistryObject<Item> COUCHLEFT = block(MdmModBlocks.COUCHLEFT);
	public static final RegistryObject<Item> COUCHMIDDLE = block(MdmModBlocks.COUCHMIDDLE);
	public static final RegistryObject<Item> COUCH_RIGHT = block(MdmModBlocks.COUCH_RIGHT);
	public static final RegistryObject<Item> COUCH_CORNER = block(MdmModBlocks.COUCH_CORNER);
	public static final RegistryObject<Item> SOFA = block(MdmModBlocks.SOFA);
	public static final RegistryObject<Item> BLACK_MODERN_FRIDGE_1 = block(MdmModBlocks.BLACK_MODERN_FRIDGE_1);
	public static final RegistryObject<Item> LEAFLESS_BAMBOO_DECORATION_1 = block(MdmModBlocks.LEAFLESS_BAMBOO_DECORATION_1);
	public static final RegistryObject<Item> LEAFLESS_BAMBOO_DECORATION_2 = block(MdmModBlocks.LEAFLESS_BAMBOO_DECORATION_2);
	public static final RegistryObject<Item> LEAFLESS_BAMBOO_DECORATION_3 = block(MdmModBlocks.LEAFLESS_BAMBOO_DECORATION_3);
	public static final RegistryObject<Item> SET_1_CABINET = block(MdmModBlocks.SET_1_CABINET);
	public static final RegistryObject<Item> SET_1_CABINET_WITH_DRAWERS = block(MdmModBlocks.SET_1_CABINET_WITH_DRAWERS);
	public static final RegistryObject<Item> SET_1_CORNER_CABINET_1 = block(MdmModBlocks.SET_1_CORNER_CABINET_1);
	public static final RegistryObject<Item> SET_1_CORNER_CABINET_2 = block(MdmModBlocks.SET_1_CORNER_CABINET_2);
	public static final RegistryObject<Item> SET_1_ISLAND_1 = block(MdmModBlocks.SET_1_ISLAND_1);
	public static final RegistryObject<Item> SET_1_ISLAND_2 = block(MdmModBlocks.SET_1_ISLAND_2);
	public static final RegistryObject<Item> SET_1_OVEN_MICROWAVE = block(MdmModBlocks.SET_1_OVEN_MICROWAVE);
	public static final RegistryObject<Item> SET_1_FRIDGE = block(MdmModBlocks.SET_1_FRIDGE);
	public static final RegistryObject<Item> SET_1_CABINET_2 = block(MdmModBlocks.SET_1_CABINET_2);
	public static final RegistryObject<Item> SET_1_HANGING_CABINET = block(MdmModBlocks.SET_1_HANGING_CABINET);
	public static final RegistryObject<Item> SET_1_CORNER_HANGING_CABINET = block(MdmModBlocks.SET_1_CORNER_HANGING_CABINET);
	public static final RegistryObject<Item> SET_2_CABINET_1 = block(MdmModBlocks.SET_2_CABINET_1);
	public static final RegistryObject<Item> SET_2_CABINET_2 = block(MdmModBlocks.SET_2_CABINET_2);
	public static final RegistryObject<Item> SET_2_CABINET_3 = block(MdmModBlocks.SET_2_CABINET_3);
	public static final RegistryObject<Item> SET_2_CABINET_WITH_DRAWERS = block(MdmModBlocks.SET_2_CABINET_WITH_DRAWERS);
	public static final RegistryObject<Item> SET_2_HANGING_SHELF = block(MdmModBlocks.SET_2_HANGING_SHELF);
	public static final RegistryObject<Item> SET_2_CORNER_COUNTER = block(MdmModBlocks.SET_2_CORNER_COUNTER);
	public static final RegistryObject<Item> BASKETS = block(MdmModBlocks.BASKETS);
	public static final RegistryObject<Item> OVEN = block(MdmModBlocks.OVEN);
	public static final RegistryObject<Item> INDUCTION_COOKER = block(MdmModBlocks.INDUCTION_COOKER);
	public static final RegistryObject<Item> HAND_SOAP_AND_CREAM_SET = block(MdmModBlocks.HAND_SOAP_AND_CREAM_SET);
	public static final RegistryObject<Item> TOILET_PAPER_ROLL = block(MdmModBlocks.TOILET_PAPER_ROLL);
	public static final RegistryObject<Item> SOAP_BAR = block(MdmModBlocks.SOAP_BAR);
	public static final RegistryObject<Item> TOILET = block(MdmModBlocks.TOILET);
	public static final RegistryObject<Item> BATHROOM_SINK = block(MdmModBlocks.BATHROOM_SINK);
	public static final RegistryObject<Item> BATHROOM_SINK_WITH_SHELF = block(MdmModBlocks.BATHROOM_SINK_WITH_SHELF);
	public static final RegistryObject<Item> BLACK_WASHBASIN_TAP = block(MdmModBlocks.BLACK_WASHBASIN_TAP);
	public static final RegistryObject<Item> WHITE_BATHROOM_SHELF = block(MdmModBlocks.WHITE_BATHROOM_SHELF);
	public static final RegistryObject<Item> RING_LAMP = block(MdmModBlocks.RING_LAMP);
	public static final RegistryObject<Item> WHITE_BATHTUB = block(MdmModBlocks.WHITE_BATHTUB);
	public static final RegistryObject<Item> TOWEL_SET_1 = block(MdmModBlocks.TOWEL_SET_1);
	public static final RegistryObject<Item> TOOTHBRUSHES = block(MdmModBlocks.TOOTHBRUSHES);
	public static final RegistryObject<Item> CHLOTHESBIN = block(MdmModBlocks.CHLOTHESBIN);
	public static final RegistryObject<Item> BATHROOM_STAND = block(MdmModBlocks.BATHROOM_STAND);
	public static final RegistryObject<Item> PILE_OF_TOWELS = block(MdmModBlocks.PILE_OF_TOWELS);
	public static final RegistryObject<Item> WALKIN_SHOWER = block(MdmModBlocks.WALKIN_SHOWER);
	public static final RegistryObject<Item> RAIN_SHOWER = block(MdmModBlocks.RAIN_SHOWER);
	public static final RegistryObject<Item> BATHROOM_MIRROR = block(MdmModBlocks.BATHROOM_MIRROR);
	public static final RegistryObject<Item> CARPET_1 = block(MdmModBlocks.CARPET_1);
	public static final RegistryObject<Item> BLACK_DESK_LAMP = block(MdmModBlocks.BLACK_DESK_LAMP);
	public static final RegistryObject<Item> MODERN_LAMP_1 = block(MdmModBlocks.MODERN_LAMP_1);
	public static final RegistryObject<Item> MODERN_DESK_LAMP_1 = block(MdmModBlocks.MODERN_DESK_LAMP_1);
	public static final RegistryObject<Item> MODERN_CHANDELIER_1 = block(MdmModBlocks.MODERN_CHANDELIER_1);
	public static final RegistryObject<Item> CEILLING_FAN = block(MdmModBlocks.CEILLING_FAN);
	public static final RegistryObject<Item> POOL_TABLE = block(MdmModBlocks.POOL_TABLE);
	public static final RegistryObject<Item> POTTED_TREE = block(MdmModBlocks.POTTED_TREE);
	public static final RegistryObject<Item> OUTDOOR_COUCH = block(MdmModBlocks.OUTDOOR_COUCH);
	public static final RegistryObject<Item> OUTDOOR_TABLE = block(MdmModBlocks.OUTDOOR_TABLE);
	public static final RegistryObject<Item> LANTERN = block(MdmModBlocks.LANTERN);
	public static final RegistryObject<Item> STREET_LANTERN_BOTTOM = block(MdmModBlocks.STREET_LANTERN_BOTTOM);
	public static final RegistryObject<Item> STREET_LANTERN_MID = block(MdmModBlocks.STREET_LANTERN_MID);
	public static final RegistryObject<Item> STREET_LATERN_TOP = block(MdmModBlocks.STREET_LATERN_TOP);
	public static final RegistryObject<Item> SET_1_NIGHT_TABLE = block(MdmModBlocks.SET_1_NIGHT_TABLE);
	public static final RegistryObject<Item> SET_1_BED = block(MdmModBlocks.SET_1_BED);
	public static final RegistryObject<Item> SET_1_FOOTREST = block(MdmModBlocks.SET_1_FOOTREST);

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
