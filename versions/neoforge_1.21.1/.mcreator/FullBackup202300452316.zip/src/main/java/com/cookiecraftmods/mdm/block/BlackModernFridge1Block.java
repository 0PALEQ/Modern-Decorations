
package com.cookiecraftmods.mdm.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.List;
import java.util.Collections;

public class BlackModernFridge1Block extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public BlackModernFridge1Block() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM).sound(SoundType.STONE).strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, BlockGetter world, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(0, 0, 1, 16, 32, 13), box(9.5, 1, 13, 15, 31, 13.5), box(1, 1, 13, 9, 31, 13.5), box(9.475, 0.975, 13, 15.025, 31.025, 13.025), box(0.975, 0.975, 13, 9.025, 31.025, 13.025), box(10, 6, 13.5, 10.25, 23, 13.75),
					box(10, 6, 13.75, 10.5, 23, 14), box(8.25, 6, 13.5, 8.5, 23, 13.75), box(8, 6, 13.75, 8.5, 23, 14), box(1, 1, 0.5, 15, 31, 1), box(0.25, 0.15, 0.975, 2.75, 0.825, 1));
			case NORTH -> Shapes.or(box(0, 0, 3, 16, 32, 15), box(1, 1, 2.5, 6.5, 31, 3), box(7, 1, 2.5, 15, 31, 3), box(0.975, 0.975, 2.975, 6.525, 31.025, 3), box(6.975, 0.975, 2.975, 15.025, 31.025, 3), box(5.75, 6, 2.25, 6, 23, 2.5),
					box(5.5, 6, 2, 6, 23, 2.25), box(7.5, 6, 2.25, 7.75, 23, 2.5), box(7.5, 6, 2, 8, 23, 2.25), box(1, 1, 15, 15, 31, 15.5), box(13.25, 0.15, 15, 15.75, 0.825, 15.025));
			case EAST -> Shapes.or(box(1, 0, 0, 13, 32, 16), box(13, 1, 1, 13.5, 31, 6.5), box(13, 1, 7, 13.5, 31, 15), box(13, 0.975, 0.975, 13.025, 31.025, 6.525), box(13, 0.975, 6.975, 13.025, 31.025, 15.025), box(13.5, 6, 5.75, 13.75, 23, 6),
					box(13.75, 6, 5.5, 14, 23, 6), box(13.5, 6, 7.5, 13.75, 23, 7.75), box(13.75, 6, 7.5, 14, 23, 8), box(0.5, 1, 1, 1, 31, 15), box(0.975, 0.15, 13.25, 1, 0.825, 15.75));
			case WEST -> Shapes.or(box(3, 0, 0, 15, 32, 16), box(2.5, 1, 9.5, 3, 31, 15), box(2.5, 1, 1, 3, 31, 9), box(2.975, 0.975, 9.475, 3, 31.025, 15.025), box(2.975, 0.975, 0.975, 3, 31.025, 9.025), box(2.25, 6, 10, 2.5, 23, 10.25),
					box(2, 6, 10, 2.25, 23, 10.5), box(2.25, 6, 8.25, 2.5, 23, 8.5), box(2, 6, 8, 2.25, 23, 8.5), box(15, 1, 1, 15.5, 31, 15), box(15, 0.15, 0.25, 15.025, 0.825, 2.75));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public List<ItemStack> getDrops(BlockState state, LootParams.Builder builder) {
		List<ItemStack> dropsOriginal = super.getDrops(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new ItemStack(this, 1));
	}
}
