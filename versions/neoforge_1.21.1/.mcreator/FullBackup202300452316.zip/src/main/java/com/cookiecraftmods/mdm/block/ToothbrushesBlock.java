
package com.cookiecraftmods.mdm.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.List;
import java.util.Collections;

public class ToothbrushesBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public ToothbrushesBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM).sound(SoundType.BAMBOO_SAPLING).strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, BlockGetter world, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(11, 0, 1, 13, 0.15, 3), box(11, 0.15, 2.9, 13, 2.3, 3), box(11, 0.15, 1, 13, 2.3, 1.1), box(12.9, 0.15, 1.1, 13, 2.3, 2.9), box(11, 0.15, 1.1, 11.1, 2.3, 2.9), box(13.7, 0.025, 0.55, 14.3, 0.425, 3.35),
					box(13.875, 0.125, 0.35, 14.125, 0.325, 0.55), box(12.55, 0, 1.275, 12.8, 3, 1.525), box(12.6, 2.5, 1.525, 12.75, 2.925, 1.7), box(11.375, 0, 1.2, 11.625, 3, 1.45), box(11.425, 2.5, 1.45, 11.575, 2.925, 1.625));
			case NORTH -> Shapes.or(box(3, 0, 13, 5, 0.15, 15), box(3, 0.15, 13, 5, 2.3, 13.1), box(3, 0.15, 14.9, 5, 2.3, 15), box(3, 0.15, 13.1, 3.1, 2.3, 14.9), box(4.9, 0.15, 13.1, 5, 2.3, 14.9), box(1.7, 0.025, 12.65, 2.3, 0.425, 15.45),
					box(1.875, 0.125, 15.45, 2.125, 0.325, 15.65), box(3.2, 0, 14.475, 3.45, 3, 14.725), box(3.25, 2.5, 14.3, 3.4, 2.925, 14.475), box(4.375, 0, 14.55, 4.625, 3, 14.8), box(4.425, 2.5, 14.375, 4.575, 2.925, 14.55));
			case EAST -> Shapes.or(box(1, 0, 3, 3, 0.15, 5), box(2.9, 0.15, 3, 3, 2.3, 5), box(1, 0.15, 3, 1.1, 2.3, 5), box(1.1, 0.15, 3, 2.9, 2.3, 3.1), box(1.1, 0.15, 4.9, 2.9, 2.3, 5), box(0.55, 0.025, 1.7, 3.35, 0.425, 2.3),
					box(0.35, 0.125, 1.875, 0.55, 0.325, 2.125), box(1.275, 0, 3.2, 1.525, 3, 3.45), box(1.525, 2.5, 3.25, 1.7, 2.925, 3.4), box(1.2, 0, 4.375, 1.45, 3, 4.625), box(1.45, 2.5, 4.425, 1.625, 2.925, 4.575));
			case WEST ->
				Shapes.or(box(13, 0, 11, 15, 0.15, 13), box(13, 0.15, 11, 13.1, 2.3, 13), box(14.9, 0.15, 11, 15, 2.3, 13), box(13.1, 0.15, 12.9, 14.9, 2.3, 13), box(13.1, 0.15, 11, 14.9, 2.3, 11.1), box(12.65, 0.025, 13.7, 15.45, 0.425, 14.3),
						box(15.45, 0.125, 13.875, 15.65, 0.325, 14.125), box(14.475, 0, 12.55, 14.725, 3, 12.8), box(14.3, 2.5, 12.6, 14.475, 2.925, 12.75), box(14.55, 0, 11.375, 14.8, 3, 11.625), box(14.375, 2.5, 11.425, 14.55, 2.925, 11.575));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public List<ItemStack> getDrops(BlockState state, LootParams.Builder builder) {
		List<ItemStack> dropsOriginal = super.getDrops(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new ItemStack(this, 1));
	}
}
