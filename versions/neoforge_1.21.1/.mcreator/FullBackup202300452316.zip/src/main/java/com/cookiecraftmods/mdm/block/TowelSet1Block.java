
package com.cookiecraftmods.mdm.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.List;
import java.util.Collections;

public class TowelSet1Block extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public TowelSet1Block() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM).sound(SoundType.WOOL).strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, BlockGetter world, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(3, 14, 1.5, 13, 15, 2), box(3, 14, 0, 4, 15, 1.5), box(3, 12, 0.5, 13, 13, 1), box(3, 12, 0, 4, 13, 0.5), box(4.25, 7, 0.4, 12.75, 13.1, 0.5), box(4.25, 3, 1, 12.75, 13.1, 1.1), box(4.25, 13, 0.5, 12.75, 13.1, 1),
					box(4.25, 9, 1.4, 12.75, 15.1, 1.5), box(4.25, 5, 2, 12.75, 15.1, 2.1), box(4.25, 15, 1.5, 12.75, 15.1, 2));
			case NORTH -> Shapes.or(box(3, 14, 14, 13, 15, 14.5), box(12, 14, 14.5, 13, 15, 16), box(3, 12, 15, 13, 13, 15.5), box(12, 12, 15.5, 13, 13, 16), box(3.25, 7, 15.5, 11.75, 13.1, 15.6), box(3.25, 3, 14.9, 11.75, 13.1, 15),
					box(3.25, 13, 15, 11.75, 13.1, 15.5), box(3.25, 9, 14.5, 11.75, 15.1, 14.6), box(3.25, 5, 13.9, 11.75, 15.1, 14), box(3.25, 15, 14, 11.75, 15.1, 14.5));
			case EAST -> Shapes.or(box(1.5, 14, 3, 2, 15, 13), box(0, 14, 12, 1.5, 15, 13), box(0.5, 12, 3, 1, 13, 13), box(0, 12, 12, 0.5, 13, 13), box(0.4, 7, 3.25, 0.5, 13.1, 11.75), box(1, 3, 3.25, 1.1, 13.1, 11.75),
					box(0.5, 13, 3.25, 1, 13.1, 11.75), box(1.4, 9, 3.25, 1.5, 15.1, 11.75), box(2, 5, 3.25, 2.1, 15.1, 11.75), box(1.5, 15, 3.25, 2, 15.1, 11.75));
			case WEST -> Shapes.or(box(14, 14, 3, 14.5, 15, 13), box(14.5, 14, 3, 16, 15, 4), box(15, 12, 3, 15.5, 13, 13), box(15.5, 12, 3, 16, 13, 4), box(15.5, 7, 4.25, 15.6, 13.1, 12.75), box(14.9, 3, 4.25, 15, 13.1, 12.75),
					box(15, 13, 4.25, 15.5, 13.1, 12.75), box(14.5, 9, 4.25, 14.6, 15.1, 12.75), box(13.9, 5, 4.25, 14, 15.1, 12.75), box(14, 15, 4.25, 14.5, 15.1, 12.75));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public List<ItemStack> getDrops(BlockState state, LootParams.Builder builder) {
		List<ItemStack> dropsOriginal = super.getDrops(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new ItemStack(this, 1));
	}
}
